from tkinter import *
import numpy as np
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg,NavigationToolbar2Tk)
from tkinter import ttk
import tkinter as tk
import matplotlib as mpl
import time
import pandas as pd
from scipy.interpolate import make_interp_spline
import sys
from daqhats import hat_list, HatIDs, mcc118
import threading
#from pid_menu_oo import myReadValues
from pid_menu_oo import myReadValuesB
#from pid_menu_oo import ReadValuesChannelB
from pid_menu_oo import Loadcallback_plot as lc
from pid_menu_oo import Stopcallback
from pid_menu_oo import NewFunctionCallback  #ActivateAcquire
from pid_menu_oo import GetComponentListA
import pid_menu_oo
from scipy.integrate import simps
import csv
import json
import os
from scipy import integrate
from scipy.signal import find_peaks
from os.path import expanduser


def ConvertToseconds(time_str):
    print('Time in mm.ss:', time_str)
    # split in  mm, ss
    mm, ss = time_str.split(':')
    
    return int(mm) * 60 + int(ss) 

def FindCompoundName(observed_retention_time,detectorName):

    print("DEBUG: FindCompound ---------------------------------------------------") 
    print("DEBUG: FindCompoundName, time = ",observed_retention_time)
    rows = []
    fields = []

    if (detectorName == "Detector-A"):
       componentTableToUse = "ComponentA.csv"
    else:
       componentTableToUse = "ComponentB.csv"

    with open(componentTableToUse, 'r') as csvfile:
        csvreader = csv.reader(csvfile)
    
        fields = next(csvreader)
    
        for row in csvreader:
            #print("DEBUG: FindCompoundName: row= ",row)
            rows.append(row)
    for row in rows:
       # print("DEBUG: Component Table :", row)
        PeakRTForACompoundAsString = row[2]
        PeakRTForACompound = ConvertToseconds(PeakRTForACompoundAsString) 
        
  
        AllowedWindowAsString = row[3]  # Available margin in secs
        window = ConvertToseconds(AllowedWindowAsString) 
        print("DEBUG:Window:", "Str= ", AllowedWindowAsString, "Numeric=",window)

        # Check whether the give observed_retention_time is matching with
        # the retention time of the current Compound in the Component Table
        #
        #
        # We have a window, if the Observerd RT falls within the window we
        # consider the given compound is matching with the current compound in the
        # table.

        print("DEBUG FindCompound", (PeakRTForACompound-window),   observed_retention_time, ( PeakRTForACompound + window))

        if PeakRTForACompound - window < observed_retention_time < PeakRTForACompound + window:
            # This compound't Peak RT is matching with the given rentention time
            print("DEBUG: FindCompound: ", row[0], "RT", observed_retention_time)
            ON_OFF_FLAG = row[1]
            if (ON_OFF_FLAG == "Yes"):       
               CompoundName = row[0]
               return CompoundName
            else:
               return "Ignored"

    # Observered Retention time did not match with any of the given compounds
    # So this compound/gas will be marked as Unknown
    return "Unknown"

def CalculatePeakAreaAndHeight(x,y,detector):

    #global detectorAObject
    curve_ListA = []
    data_ListA = []
    data_List_aY = []
    data_List_aX = []
    curveList_aY = y
    curveList_aX = x
    peak_rt = 0.0
    max_data = 0.0

    global componentsTableObject

    print("DEBUG:CalculatePeakAreaAndHeight")
    for curveValue_aX,curveValue_aY in zip(curveList_aX,curveList_aY):
        # Replace 1.0 with value from UI
        if curveValue_aY > 1.0:
            data_ListA.append((curveValue_aX,curveValue_aY))
            data_List_aX.append(curveValue_aX)
            data_List_aY.append(curveValue_aY)

        elif not data_ListA == []:
            print("DEBUG:CalculatePeakAreaAndHeight: One cycle detected")
            #print("DEBUG:CalculatePeakAreaAndHeight: ","aX=",curveValue_aX,"aY",curveValue_aY)
            # Initalize both the variables with the
            # first value in array, so that in case the zero-th element is peak
            # we don't miss it.
            max_data = data_List_aY[0]
            peak_rt = data_List_aX[0]
            peak_rt = round(peak_rt,2)
            for i,j in zip(data_List_aX,data_List_aY):
                if j>max_data:
                    max_data = j
                    peak_rt = i
                    peak_rt = round(peak_rt,2)
               #print(" |DEBUG:i,j max_data" ,i, " ",j, max_data,"|", end = '')


            #print("DEBUG:CalculatePeakAreaAndHeight: ","i=",i,"j=",j)
            peak_height = max_data
            peak_height = round(peak_height,2)
            peak_area   = simps(data_List_aY,dx=0.2)
            peak_area   = round(peak_area,2)
            #print("DEBUG: CalculatePeakAreaAndHeight","Peak Height= " ,peak_height, "Peak RT= ", peak_rt)
            # ------------------- Begin Most Important Routine ---------------------------
            compound_name = FindCompoundName(peak_rt,detector)
            # -------------------  End Most Important Routine ---------------------------
            RetentionTimeMinutesPart = int(peak_rt/60) 
            RetentionTimeSecondsPart = int(peak_rt%60) 
            RetentionTimeMinuteColonSecFormat = str(RetentionTimeMinutesPart) + ":" + str(RetentionTimeSecondsPart)

            curve_ListA.append(dict(peak_height = peak_height,
                                    peak_area = peak_area,
                                    peak_RT=peak_rt,
                                    peak_RTHrMinFormat = RetentionTimeMinuteColonSecFormat,
                                    CompoundName =compound_name))
           
            data_ListA = []
            data_List_aY = []
            data_List_aX = []
            peak_rt = 0.0
            max_data = 0.0
        else:
            #print("Length of data_List= ", len(data_ListA))
            #print("Length of data_List_aY= ", len(data_List_aY))
            #print("Length of data_List_aX= ", len(data_List_aX))
            pass
    return curve_ListA

class PlotGraphClass:
  def __init__(self, parentwindow):
        self.parentWindow      = parentwindow
        global prominence_set
        self.prominence_set = IntVar()
        self.aX_Save_values =  []
        self.aY_Save_values =  []
        self.bX_Save_values =  []
        self.bY_Save_values =  []
        self.aX_plot_values = []
        self.aY_plot_values = []
        self.bX_plot_values = []
        self.bY_plot_values = []
        self.plotValuesFlagA = 0
        self.plotValuesFlagB = 0
        
        self.GraphAPopUpWindow = None
        self.GraphBPopUpWindow = None
        self.TopFrame          = None
        self.BottomFrame       = None
        
        self.TableAPopUpWindow = None
        self.TableBPopUpWindow = None
        self.TableA            = None
        self.TableB            = None
        self.TableAData        = []
        self.TableBData        = []
        self.TopLeftRootX      = 0
        self.TopLeftRootY      = 0
        self.BottomRightRootX  = 1199 
        self.BottomRightRootY  = 599

        self.JOBFileName = ""  # JOB File name is needed for generating JPG files #

  def PushPlotsAndTableDown(self):
        if (self.GraphAPopUpWindow != None):
           self.GraphAPopUpWindow.attributes('-topmost',False)
        if (self.GraphBPopUpWindow != None):   
           self.GraphBPopUpWindow.attributes('-topmost',False)
        if (self.TableAPopUpWindow != None):
           self.TableAPopUpWindow.attributes('-topmost',False)
        if (self.TableBPopUpWindow != None):
           self.TableBPopUpWindow.attributes('-topmost',False)  
        return
        
  def PushPlotsAndTableUp(self):
        if (self.GraphAPopUpWindow != None):
           self.GraphAPopUpWindow.attributes('-topmost',True)
        if (self.GraphBPopUpWindow != None):   
           self.GraphBPopUpWindow.attributes('-topmost',True)
        if (self.TableAPopUpWindow != None):
           self.TableAPopUpWindow.attributes('-topmost',True)
        if (self.TableBPopUpWindow != None):
           self.TableBPopUpWindow.attributes('-topmost',True)  
        return        
        
  def UpdateTopLeftCoordsOfRootWindow(self,event):
      self.topLeftX = event.x
      self.topLeftY = event.y
      
      # Following are absolute locations on the screen
      # and not the x,y relative to root.
      #self.TopLeftRootX = event.x 
      #self.TopLeftRootY = event.y
      
      self.TopLeftRootX = self.parentWindow.winfo_x()
      self.TopLeftRootY = self.parentWindow.winfo_y()
      
      self.BottomRightRootX = self.parentWindow.winfo_x()+1199
      self.BottomRightRootY = self.parentWindow.winfo_y()+599

      #print("UpdateTopLeftCoordsOfRootWindow:","x= ",self.TopLeftRootX,"y=",self.TopLeftRootY)
      
      if (self.GraphAPopUpWindow != None):      
        self.GraphAPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+70))))
        
      if (self.TableAPopUpWindow != None):        
        self.TableAPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+603),(self.TopLeftRootY+70))))  
        
      if (self.GraphBPopUpWindow != None):            
        self.GraphBPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+325))))   
        
      if (self.TableBPopUpWindow != None):            
        self.TableBPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+603),(self.TopLeftRootY+325))))             
                    
      return
        
  def SetTableAData(self,data):
      print("DEBUG: SetTableAData")
      self.TableAData =[]
      self.table_list = []

      CompoundNameAndDetailsList = CalculatePeakAreaAndHeight(self.aX_Save_values,
                                                     self.aY_Save_values,"Detector-A")

      print("DEBUG:SetTableAData: No of Compound detected", len(CompoundNameAndDetailsList))

      print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
      for row  in CompoundNameAndDetailsList:
          self.table_list.append(row['CompoundName'])       # Name
          self.table_list.append("0.0")                     # Conc 
          self.table_list.append(row['peak_height'])        # Height 
          self.table_list.append("0.0")                     # %
          self.table_list.append(row['peak_area'])          # Area 
          self.table_list.append(row['peak_RTHrMinFormat']) # % 
          self.table_list.append(row['peak_RT'])            # Time 
          # Add this to table data structure
          self.TableAData.append(self.table_list)
          self.table_list =[] 
 
      print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

      CompoundNameAndDetailsList = []
      self.table_list =[]

      print("DEBUG:SetTableAData", self.TableAData)
      return

  def SetTableBData(self,data):
      print("DEBUG: SetTableBData")
      self.TableBData =[]
      self.table_list = []

      CompoundNameAndDetailsList = CalculatePeakAreaAndHeight(self.bX_Save_values,
                                                     self.bY_Save_values,"Detector-B")

      #CompoundNameAndDetailsList = CalculatePeakAreaAndHeight(self.aX_Save_values,
      #                                               self.aY_Save_values)

      print("DEBUG:SetTableAData: No of Compound detected", len(CompoundNameAndDetailsList))

      print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
      for row  in CompoundNameAndDetailsList:
          self.table_list.append(row['CompoundName'])       # Name
          self.table_list.append("0.0")                     # Conc
          self.table_list.append(row['peak_height'])        # Height
          self.table_list.append("0.0")                     # %
          self.table_list.append(row['peak_area'])          # Area
          self.table_list.append(row['peak_RTHrMinFormat']) # %
          self.table_list.append(row['peak_RT'])            # Time
          # Add this to table data structure
          self.TableBData.append(self.table_list)
          self.table_list =[]

      print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
      CompoundNameAndDetailsList =[]
      self.table_list =[]
      print("DEBUG:SetTableBData", self.TableBData)
      return
    
  def plotA_running(self,stopA):
      figure = Figure(figsize=(15, 10))
      figure.patch.set_facecolor('#ECF0F1')  # The region our side plot get a different color
      subplot = figure.subplots()
      subplot.set_facecolor("#000001") # Region inside the plot      
      subplot.grid()
      canvas = FigureCanvasTkAgg(figure, master=self.GraphAPopUpWindow)
      subplot.set_title("Detector  A")
      canvas.draw()
      canvas.flush_events()
      canvas.get_tk_widget().pack(side=TOP)
      while True:
          try:
            if self.plotValuesFlagA == 0:
              self.plotValuesFlagA = 1
              subPlotHandle, = subplot.plot(self.aX_plot_values, self.aY_plot_values, color='#FF6700')
              self.plotValuesFlagA = 0
          except ValueError as e:
              print("\n\n[ERROR]",e)
              exit()
          canvas.draw()
          canvas.flush_events()
          if stopA():
              break
      return
    
  def plotA(self):
      global stop_threadsA, myPlotA_thread
      stop_threadsA = False
      myPlotA_thread = threading.Thread(target=self.plotA_running,args =(lambda : stop_threadsA,))
      myPlotA_thread.start()
      return
    
  def stop_threading_A(self):
      global stop_threadsA,myPlotA_thread
      stop_threadsA = True
      #myPlotA_thread.join()
      return
        
  def plotB_running(self,stopB):
      global stop_threadsB
      figure = Figure(figsize=(15, 10))
      figure.patch.set_facecolor('#ECF0F1')  # The region our side plot get a different color
      subplot = figure.subplots()
      subplot.set_facecolor("#000001") # Region inside the plot      
      subplot.grid()
      canvas = FigureCanvasTkAgg(figure, master=self.GraphBPopUpWindow)
      subplot.set_title("Detector  B")
      canvas.flush_events()
      canvas.get_tk_widget().pack(side=TOP)
      while True:
          try:
            if self.plotValuesFlagB == 0:
              self.plotValuesFlagB = 1
              subPlotHandle, = subplot.plot(self.bX_plot_values, self.bY_plot_values, color='#00B5FF')
              self.plotValuesFlagB = 0
          except ValueError as e:
              print("\n\n[ERROR]",e)
              exit()
          canvas.draw()
          canvas.flush_events()
          if stopB():
              break
      return
    
  def plotB(self):
      global stop_threadsB,myPlotB_thread
      stop_threadsB = False
      myPlotB_thread = threading.Thread(target=self.plotB_running,args =(lambda : stop_threadsB, ))
      myPlotB_thread.start()
      return
   
  def stop_threading_B(self):
      global stop_threadsB,myPlotB_thread
      stop_threadsB = True
      #myPlotB_thread.join()
      return
  
  def plotA_Cons(self):
      #global self.aX_values,self.aY_values
      figure = Figure(figsize=(15, 10))
      figure.patch.set_facecolor('#ECF0F1')  # The region our side plot get a different color
      subplot = figure.subplots()
      #print(self.aY_values)
      aXValueinMinutes = []
      # Experiment 
      '''
      for item in self.aX_Save_values:
              mins = int(int(item)/60)
              sec  = int(int(item)%60)
              xstr = str(mins) + ":" + str(sec)
              aXValueinMinutes.append(xstr) 
      '''
      # -- end of Experiment
      subPlotHandle = subplot.plot(self.aX_Save_values,self.aY_Save_values,color='#FF6700')
      #subPlotHandle = subplot.plot(aXValueinMinutes,self.aY_Save_values,color='#FF6700')
      #DataInTableA  = PIDGraphObject.TableAData

      # Add label to peaks ....
      count = 1 
      for entry in self.TableAData:
       compoundName = entry[0]
       peakHeight = entry[2]
       retentionTime = entry[6]
       x = retentionTime 
       y = peakHeight 
       subplot.text(x,y,str(count),color='yellow', fontsize=10)
       count = count + 1

      subplot.set_facecolor("#000001") # Region inside the plot      
      subplot.grid()
      
      canvas = FigureCanvasTkAgg(figure, master=self.GraphAPopUpWindow)
      subplot.set_title("Detector A")
      canvas.draw()
      canvas.get_tk_widget().pack(side=TOP)
    
      if (self.JOBFileName == ""):
          self.JOBFileName = "Default-Job-Name.job" 
      projectName = os.path.splitext(self.JOBFileName)[0]
      jpgFileName = projectName + "-Detector-1" + ".jpg"
      canvas.print_jpg(jpgFileName)
      return
    
  def plotB_Cons(self):
      global FileMenuOptionsObject
      area_array = []
      height_array = []
      #global self.bX_values,self.bY_values
      #print("DEBUG:plotB_Cons")
      figure = Figure(figsize=(15, 10))
      figure.patch.set_facecolor('#ECF0F1')  # The region our side plot get a different color
      subplot = figure.subplots()
      subPlotHandle =subplot.plot(self.bX_Save_values,self.bY_Save_values, color='#00B5FF')
      # Add label to peaks ....
      count = 1
      for entry in self.TableBData:
       compoundName = entry[0]
       peakHeight = entry[2]
       retentionTime = entry[6]
       x = retentionTime
       y = peakHeight
       subplot.text(x,y,str(count),color='yellow', fontsize=10)
       count = count + 1

      subplot.set_facecolor("#000001") # Region inside the plot      

      subplot.grid()
      
      canvas = FigureCanvasTkAgg(figure, master=self.GraphBPopUpWindow)
      subplot.set_title("Detector B")
      canvas.draw()
      canvas.get_tk_widget().pack(side=TOP)
      if (self.JOBFileName == ""):
          self.JOBFileName = "Default-Job-Name.job"
      projectName = os.path.splitext(self.JOBFileName)[0]

      jpgFileName = projectName + "-Detector-2" + ".jpg"
      canvas.print_jpg(jpgFileName)

      return
      
  def onClosingA(self):
      #print("Onclosing A")
      self.GraphAPopUpWindow.destroy()
      self.GraphAPopUpWindow = None
      return
      
  def onClosingB(self):
      #print("Onclosing B")
      self.GraphBPopUpWindow.destroy()
      self.GraphBPopUpWindow = None
      return
      
  def PopUpAWindowMove(self,event):
      
      '''
      print("PopUpAWindowMove", "event.height" , event.height, 
                                "event.width",event.width,
                                "event.x", event.x,
                                "event.y", event.y)
      '''
      
      return

  def PopUpGraphA_Cons(self):
    #if (self.TopFrame != None):
    #    # Close the tiled charts
    #    self.TopFrame.destroy()
    #   self.TopFrame = None 

    print("DEBUG:PopUpGraphA_Cons")
    self.SetTableAData("x")
    if (self.GraphAPopUpWindow != None):
        # We do not want to open multiple windows of the same chart
        return 
        
    #print(self.GraphAPopUpWindow)
    self.GraphAPopUpWindow= Toplevel(self.parentWindow)
    self.GraphAPopUpWindow.protocol("WM_DELETE_WINDOW", self.onClosingA)
    self.GraphAPopUpWindow.geometry("592x220")
    self.GraphAPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+70))))
    string = "+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+100))
    #print("PopUpGraphA:GraphAPopUpWindow:",string)    

    #self.GraphAPopUpWindow.transient(self.parentWindow)
    self.GraphAPopUpWindow.attributes('-topmost',True)
    #title_bar = Frame(self.GraphAPopUpWindow, relief='raised', bd=6)
    #title_bar.pack(expand=1, fill=X)
    #title_bar.pack(expand=1, fill=X)
    self.GraphAPopUpWindow.title("GraphA")
    #windowWidth   = self.GraphAPopUpWindow.winfo_reqwidth()
    #windowHeight  = self.GraphAPopUpWindow.winfo_reqheight()
    #positionRight = int(self.GraphAPopUpWindow.winfo_screenwidth()/4 - windowWidth/2)
    #positionDown  = int(self.GraphAPopUpWindow.winfo_screenheight()/4 - windowHeight/2)
    #print("Position Right=",positionRight, "Position Down= ",positionDown)
    #self.GraphAPopUpWindow.geometry("+{}+{}".format(positionRight, positionDown))
    
    #self.GraphAPopUpWindow.resizable(False, False)
    self.GraphAPopUpWindow.bind('<Configure>', self.PopUpAWindowMove)
    #self.GraphAPopUpWindow.lift() 
    self.plotA_Cons()
   
  def PopUpGraphB_Cons(self):
  
    print("DEBUG:PopUpGraphB_Cons")
    if (self.BottomFrame != None):
        self.BottomFrame.destroy()   
        self.BottomFrame = None
        
    if (self.GraphBPopUpWindow != None):
        # We do not want to open multiple windows of the same chart
        print("Window already opened")
        return 
    self.SetTableBData("x")    
    self.GraphBPopUpWindow= Toplevel(self.parentWindow)
    self.GraphBPopUpWindow.protocol("WM_DELETE_WINDOW", self.onClosingB)
    self.GraphBPopUpWindow.geometry("592x220")
    self.GraphBPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+325))))    
    self.GraphBPopUpWindow.title("GraphB")
    #self.GraphBPopUpWindow.transient(self.parentWindow)
    self.GraphBPopUpWindow.attributes('-topmost',True)
    self.GraphBPopUpWindow.bind('<Configure>', self.PopUpBWindowMove)
    #title_bar = Frame(self.GraphBPopUpWindow, bg='red', relief='raised', bd=6)
    #title_bar.pack(expand=1, fill=X)    
    #self.GraphBPopUpWindow.transient(self.parentWindow)
    #windowWidth   = self.GraphBPopUpWindow.winfo_reqwidth()
    #windowHeight  = self.GraphBPopUpWindow.winfo_reqheight()
    #positionRight = int(self.GraphBPopUpWindow.winfo_screenwidth()/3 - windowWidth/2)
    #positionDown  = int(self.GraphBPopUpWindow.winfo_screenheight()/3 - windowHeight/2)
    #self.GraphBPopUpWindow.geometry("+{}+{}".format(positionRight, positionDown))    
    self.plotB_Cons()
    
  def PopUpGraphA(self):
    #if (self.TopFrame != None):
    #    # Close the tiled charts
    #    self.TopFrame.destroy()
    #   self.TopFrame = None 
    #self.SetTableAData("x")
    if (self.GraphAPopUpWindow != None):
        # We do not want to open multiple windows of the same chart
        return 
        
    #print(self.GraphAPopUpWindow)
    self.GraphAPopUpWindow= Toplevel(self.parentWindow)
    self.GraphAPopUpWindow.protocol("WM_DELETE_WINDOW", self.onClosingA)
    self.GraphAPopUpWindow.geometry("592x220")
    self.GraphAPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+70))))
    string = "+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+100))
    #print("PopUpGraphA:GraphAPopUpWindow:",string)    

    #self.GraphAPopUpWindow.transient(self.parentWindow)
    self.GraphAPopUpWindow.attributes('-topmost',True)
    #title_bar = Frame(self.GraphAPopUpWindow, relief='raised', bd=6)
    #title_bar.pack(expand=1, fill=X)
    #title_bar.pack(expand=1, fill=X)
    self.GraphAPopUpWindow.title("GraphA")
    #windowWidth   = self.GraphAPopUpWindow.winfo_reqwidth()
    #windowHeight  = self.GraphAPopUpWindow.winfo_reqheight()
    #positionRight = int(self.GraphAPopUpWindow.winfo_screenwidth()/4 - windowWidth/2)
    #positionDown  = int(self.GraphAPopUpWindow.winfo_screenheight()/4 - windowHeight/2)
    #print("Position Right=",positionRight, "Position Down= ",positionDown)
    #self.GraphAPopUpWindow.geometry("+{}+{}".format(positionRight, positionDown))
    
    #self.GraphAPopUpWindow.resizable(False, False)
    self.GraphAPopUpWindow.bind('<Configure>', self.PopUpAWindowMove)
    #self.GraphAPopUpWindow.lift() 
    self.plotA()
    
  def PopUpBWindowMove(self,event):

      '''
      print("PopUpBWindowMove", "event.height" , event.height, 
                                "event.width",event.width,
                                "event.x", event.x,
                                "event.y", event.y)
      '''
      
      return
    
  def PopUpGraphB(self):
  
    if (self.BottomFrame != None):
        self.BottomFrame.destroy()   
        self.BottomFrame = None
        
    if (self.GraphBPopUpWindow != None):
        # We do not want to open multiple windows of the same chart
        return 
    #self.SetTableBData("x")    
    self.GraphBPopUpWindow= Toplevel(self.parentWindow)
    self.GraphBPopUpWindow.protocol("WM_DELETE_WINDOW", self.onClosingB)
    self.GraphBPopUpWindow.geometry("592x220")
    self.GraphBPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+325))))    
    self.GraphBPopUpWindow.title("GraphB")
    #self.GraphBPopUpWindow.transient(self.parentWindow)
    self.GraphBPopUpWindow.attributes('-topmost',True)
    self.GraphBPopUpWindow.bind('<Configure>', self.PopUpBWindowMove)
    #title_bar = Frame(self.GraphBPopUpWindow, bg='red', relief='raised', bd=6)
    #title_bar.pack(expand=1, fill=X)    
    #self.GraphBPopUpWindow.transient(self.parentWindow)
    #windowWidth   = self.GraphBPopUpWindow.winfo_reqwidth()
    #windowHeight  = self.GraphBPopUpWindow.winfo_reqheight()
    #positionRight = int(self.GraphBPopUpWindow.winfo_screenwidth()/3 - windowWidth/2)
    #positionDown  = int(self.GraphBPopUpWindow.winfo_screenheight()/3 - windowHeight/2)
    #self.GraphBPopUpWindow.geometry("+{}+{}".format(positionRight, positionDown))    
    self.plotB()    
    
  def TileHorizontalA(self):
    '''
    if (self.GraphAPopUpWindow != None):
        self.onClosingA()
        
    if (self.TopFrame != None):
        return
        
    self.TopFrame = Frame(self.parentWindow,borderwidth=4,relief=GROOVE)
    self.plotA("tile")    
    self.TopFrame.pack(side=TOP)
    '''
    return
  def TileHorizontalB(self):
    '''
    if (self.GraphBPopUpWindow != None):
       self.onClosingB()
       
    if (self.BottomFrame != None):
        return
        
    self.BottomFrame = Frame(self.parentWindow,borderwidth=4,relief=GROOVE)
    self.plotB("tile")  
    self.BottomFrame.pack(side=TOP)
    '''
    return
    
  def TileHorizontal(self):
    self.TileHorizontalA()
    self.TileHorizontalB()

  def CloseAll(self):

        if (self.BottomFrame != None):
            self.BottomFrame.destroy()   
            self.BottomFrame = None
            
        if (self.TopFrame != None):
            self.TopFrame.destroy()   
            self.TopFrame = None

        if (self.GraphAPopUpWindow != None):
            self.GraphAPopUpWindow.destroy()
            self.GraphAPopUpWindow = None
            
        if (self.GraphBPopUpWindow != None):
            self.GraphBPopUpWindow.destroy()
            self.GraphBPopUpWindow = None
            
        if (self.TableAPopUpWindow != None):
            self.TableAPopUpWindow.destroy()
            self.TableAPopUpWindow = None

        if (self.TableBPopUpWindow != None):
            self.TableBPopUpWindow.destroy()
            self.TableBPopUpWindow = None
        
        
  def ShowTableA(self,ParentWindow):
        frame=ParentWindow
        columns = ('name', 'concentration1', 'height', 'percentage1', 'area', 'rt-min-sec', 'time')
        self.TableA = ttk.Treeview(frame, columns=columns, show='headings',height=10)
        frame.pack(side=TOP)
        style = ttk.Style(ParentWindow)
        style.theme_use("clam")
        style.configure(self.TableA.heading, background="black", foreground="white")
        # Create Headings
        self.TableA.heading('name', text='Name')
        self.TableA.column('name', minwidth=0, width=200, stretch=True)
        
        self.TableA.heading('concentration1', text='Conc')
        self.TableA.column('concentration1', minwidth=0, width=60,stretch=True)
        self.TableA.heading('height', text='Height')
        self.TableA.column('height', minwidth=0, width=60,stretch=True)
        self.TableA.heading('percentage1', text='%')
        self.TableA.column('percentage1', minwidth=0, width=50,stretch=True)
        self.TableA.heading('area', text='Area')
        self.TableA.column('area', minwidth=0, width=80,stretch=True)
        self.TableA.heading('rt-min-sec', text='RT-M:S')
        self.TableA.column('rt-min-sec', minwidth=0, width=70,stretch=True)
        self.TableA.heading('time', text='RT-Sec')
        self.TableA.column('time', minwidth=0, width=50, stretch=True)
        #self.TableA.bind('<Double-1>', self.ItemSelectedInTableA)
        #self.TableA.bind('<<TreeviewSelect>>', self.ItemFocusedInTableA)
        self.TableA.pack(side=LEFT)
      
        # Create scrollbar
        scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=self.TableA.yview)
        self.TableA.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=LEFT,fill='both', expand=1)
      
        # add data to the treeview
        print("DEBUG:ShowTableA", self.TableAData)
        for entry in self.TableAData:
           self.TableA.insert('', tk.END, values=entry)
        
        return
        
  def ShowTableB(self,ParentWindow):
        frame=ParentWindow
        columns = ('name', 'concentration1', 'height', 'percentage1', 'area', 'rt-min-sec', 'time')
        self.TableB = ttk.Treeview(frame, columns=columns, show='headings',height=10)
        frame.pack(side=TOP)
        style = ttk.Style(ParentWindow)
        style.theme_use("clam")
        style.configure(self.TableB.heading, background="black", foreground="white")

        # Create Headings
      
        self.TableB.heading('name', text='Name')
        self.TableB.column('name', minwidth=0, width=200, stretch=True)
        
        self.TableB.heading('concentration1', text='Conc')
        self.TableB.column('concentration1', minwidth=0, width=60,stretch=True)
        
        self.TableB.heading('height', text='Height')
        self.TableB.column('height', minwidth=0, width=60,stretch=True)
        
        self.TableB.heading('percentage1', text='%')
        self.TableB.column('percentage1', minwidth=0, width=50,stretch=True)
        
        self.TableB.heading('area', text='Area')
        self.TableB.column('area', minwidth=0, width=80,stretch=True)
        
        self.TableB.heading('rt-min-sec', text='RT-M:S')
        self.TableB.column('rt-min-sec', minwidth=0, width=50,stretch=True)
        
        self.TableB.heading('time', text='RT-Sec')
        self.TableB.column('time', minwidth=0, width=70, stretch=True)
        
        #self.TableA.bind('<Double-1>', self.ItemSelectedInTableA)
        #self.TableA.bind('<<TreeviewSelect>>', self.ItemFocusedInTableA)
        self.TableB.pack(side=LEFT)
      
        # Create scrollbar
        scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=self.TableB.yview)
        self.TableB.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=LEFT,fill='both', expand=1)
      
        # add data to the treeview
        for entry in self.TableBData:
           self.TableB.insert('', tk.END, values=entry)

        return
        
  def onClosingTableA(self):
      self.TableAPopUpWindow.destroy()
      self.TableAPopUpWindow = None
      
  def onClosingTableB(self):
      self.TableBPopUpWindow.destroy()
      self.TableBPopUpWindow = None
      
  def TableAPopUpWindowMove(self,event): 
        
      #print("TableAPopUpWindowMove:", "event.height" , event.height, 
      #                          "event.width",event.width,
      #                          "event.x", event.x,
      #                          "event.y", event.y)  
      
      return
      
  def CreateTableA(self):
  
     if (self.TableAPopUpWindow != None):
        # We do not want to open multiple windows of the same chart
        return 

     
     self.TableAPopUpWindow= Toplevel(self.parentWindow)    
     self.TableAPopUpWindow.attributes('-topmost',True)
     self.TableAPopUpWindow.geometry("592x220")
     self.TableAPopUpWindow.resizable(False, False)
     self.TableAPopUpWindow.protocol("WM_DELETE_WINDOW", self.onClosingTableA)
     self.TableAPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+603),(self.TopLeftRootY+70))))
     self.TableAPopUpWindow.title("TableA")
     self.TableAPopUpWindow.lift()
     frame=Frame(self.TableAPopUpWindow)

     #self.TableAPopUpWindow.bind('<Configure>', self.TableAPopUpWindowMove)
     self.ShowTableA(frame)

     return
     
  def CreateTableB(self):
  
     if (self.TableBPopUpWindow != None):
        # We do not want to open multiple windows of the same chart
        return 
        
     self.TableBPopUpWindow= Toplevel(self.parentWindow)
     self.TableBPopUpWindow.attributes('-topmost',True)
     self.TableBPopUpWindow.geometry("592x220")     
     self.TableBPopUpWindow.resizable(False, False)     
     self.TableBPopUpWindow.protocol("WM_DELETE_WINDOW", self.onClosingTableB)
     self.TableBPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+603),(self.TopLeftRootY+325))))     
     self.TableBPopUpWindow.title("TableB")
          
     
     #self.TableBPopUpWindow.lift()
     frame=Frame(self.TableBPopUpWindow)
     self.ShowTableB(frame)
     
  def ArrageAll(self):
  
      if (self.GraphAPopUpWindow != None):         
        self.GraphAPopUpWindow.lift()
        self.GraphAPopUpWindow.attributes('-topmost',True)
        self.GraphAPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+70))))
        #print("ArrangeAll GraphAPopUpWindow:",self.TopLeftRootX,self.TopLeftRootY)
        string = "+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+100))
        #print("ArrangeAll GraphAPopUpWindow:",string)
        
      if (self.TableAPopUpWindow != None):
        self.TableAPopUpWindow.lift()
        self.TableAPopUpWindow.attributes('-topmost',True)
        self.TableAPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+603),(self.TopLeftRootY+70))))        
        #print("ArrangeAll TableAPopUpWindow:",(self.TopLeftRootX+603),(self.TopLeftRootY+100))
        
      if (self.GraphBPopUpWindow != None):
        self.GraphBPopUpWindow.lift()
        self.GraphBPopUpWindow.attributes('-topmost',True)
        self.GraphBPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+5),(self.TopLeftRootY+325))))    
        #print("ArrangeAll GraphBPopUpWindow:",(self.TopLeftRootX+5),(self.TopLeftRootY+320))
        
      if (self.TableBPopUpWindow != None):
        self.TableBPopUpWindow.lift()
        self.TableBPopUpWindow.attributes('-topmost',True)
        self.TableBPopUpWindow.geometry(("+{0}+{1}".format((self.TopLeftRootX+603),(self.TopLeftRootY+325))))     
        #print("ArrangeAll TableBPopUpWindow:",(self.TopLeftRootX+603),(self.TopLeftRootY+320))
        
      return         
        
  

