import json
class PidSettings:
   def __init__(self):
        self.workspaceFolder = ""
        self.samplingIntervalTime = ""
        self.pidRunName = "None"
   
   def ReadSettingFile(self):
        # Read PIDSettings.json
        # First open the JSON file

        try:
           jsonFileHandle = open("PIDSettings.json")
        except ValueError as IOError:
           print("File opening failed : Unable to open the pid_settings.json file.")
           return False

        # Load the  JOB file
        try:
           jsonData = json.load(jsonFileHandle)
        except ValueError as e:
           print("Incorrect Format: pid_settings.json  file is not in correct format, is it corrupted?")
           return False

        # Close the JOB file
        jsonFileHandle.close()

        self.workspaceFolder = jsonData["WorkSpace"]
        self.samplingIntervalTime = jsonData["SamplingInterval"]
        self.pidRunName  = jsonData["PIDRunName"]

        if self.workspaceFolder == "" :
           print("Incorrect pid_settings.json")
           return False

        if self.samplingIntervalTime  == "" :
           print("Incorrect pid_settings.json")
           return False
            
        #print("Successfully read,  pid_settings.json")
        return True

