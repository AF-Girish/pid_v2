#! /usr/bin/python3 
import json
import time
import sys
import os
import csv
import threading
import datetime
import os
import subprocess
import re
#from daqhats import mcc118, OptionFlags, HatIDs, HatError
#import daqhats_utils as daqutils


def VerifyMCC118():
    channels = [0, 1, 2, 3]
    channel_mask = daqutils.chan_list_to_mask(channels)
    num_channels = len(channels)

    samples_per_channel = 10000
    scan_rate = 1000.0
    options = OptionFlags.DEFAULT

    try:
        # Select an MCC 118 HAT device to use.
        address = daqutils.select_hat_device(HatIDs.MCC_118)
        hat = mcc118(address)
    except (HatError, ValueError) as err:
        print('\n', err)
        print("Unable to communicate with  MCC118 Data Acquisition  Board")
        return False
    print("Peak Works, MCC 118 Data Acquistion Card : Verified: OK")

    return True


def VerifyPIDSettings():
        # Check for PIDSetting.json
        if(os.path.exists("PIDSettings.json") == False):
          print("File, ", "PIDSettings.json", "Does not exist");
          print("Critical Data file missing in installation, - Need to reinstall Peak Works ")
          print("Exiting.... ")
          return False
        R_OK_flag = os.access("PIDSettings.json" , os.R_OK) # Check for read access
        if (R_OK_flag == False):
          print("Data file ", "PIDSettings.json", "does not have read permission, pls correct this")
          print("Exiting....")
          return False

        # Read PIDSettings.json
        # Now the we have verified that file is existing with read premission
        # We will open the JSON file and examine its contents
        try:
           jsonFileHandle = open("PIDSettings.json")
        except ValueError as IOError:
           print("File opening failed : Unable to open the PIDSettings.json file.")
           return False

        # Load the  JOB file
        try:
           jsonData = json.load(jsonFileHandle)
        except ValueError as e:
           print("Incorrect Format: PIDSettings.json  file is not in correct format, is it corrupted?")
           return False

        # Close the JOB file
        jsonFileHandle.close()

        # Now Check the contents of the file 
        workspaceFolder = jsonData["WorkSpace"]
        samplingIntervalTime = jsonData["SamplingInterval"]
        pidRunName  = jsonData["PIDRunName"]

        if workspaceFolder == "" :
           print("Incorrect pid_settings.json")
           return False

        if samplingIntervalTime  == "" :
           print("Incorrect pid_settings.json")
           return False
        print("PID Setting File ,  pid_settings.json", "Verified:OK")

        isdir = os.path.isdir(workspaceFolder)
        if (isdir == True):
            # Checking read write permissions
            R_OK_flag = os.access(workspaceFolder, os.R_OK) # Check for read access
            if (R_OK_flag == False):
               print("PeakWorks Workspace folder ", workspaceFolder , " does not have permission to read files")
               print("Make sure the Work space path mentioned in pidsettings.json file has read permission")
               return False 

            W_OK_flag = os.access(workspaceFolder, os.W_OK) # Check for write access
            if (W_OK_flag == False):
               print("PeakWorks Workspace folder ", workspaceFolder , " does not have permission create or modifiy files ")
               print("Make sure the Work space path mentioned in pidsettings.json file has write permission")
               print("Exiting")
               return False
            X_OK_flag = os.access(workspaceFolder, os.X_OK) # Check for execution access
            if (X_OK_flag == False):
               print("PeakWorks Workspace folder ", workspaceFolder , " does not have permission to execute programs ")
               print("Make sure the Work space path mentioned in pidsettings.json file has execute permission")
               print("Exiting")
               return False
        else:
            print("Peak Works Work Space folder",workspaceFolder  ," does not exist")
        return True
        print("Peak Works Work Space folder",workspaceFolder  ," Verified OK")

def VerifyDataFiles():
  # Check for files in executable folder
  dataFiles = ['ComponentA.csv','ComponentB.csv','StandardsA.csv','StandardsB.csv']
  for file in dataFiles:
      if(os.path.exists(file) == False):
        print("File, ", file, "Does not exist");
        print("Critical Data file missing in installation, - Need to reinstall Peak Works ")
        print("Exiting.... ")
        return False 
      R_OK_flag = os.access(file , os.R_OK) # Check for read access
      if (R_OK_flag == False):
          print("Data file ", file , "does not have read permission, pls correct this")
          print("Exiting....")
          return False 
      W_OK_flag = os.access(file , os.W_OK) # Check for read access
      if (W_OK_flag == False):
          print("Data file ", file , "does not have read permission, pls correct this")
          print("Exiting....")
          return False 
  print("Peak Works Data files : Verified: OK")
  return True

def VerifyImageFiles():
  # Check for image files(Icons)  in executable folder
  imageFiles = ['ACQUIRE.png','D_CLOSE.png','EXIT.png','LAMP_ON.png','NEW.png','PRINT.png','SAVE.png','STOP.png']
  imageFiles  = imageFiles + ['AZ_B.png','D_OPEN.png','LAMP_OFF.png','LOAD.png','pid_analyzer.png','RUN.png','SCALE_NO.png']

  for file in imageFiles:
      if(os.path.exists(file) == False):
        print("File, ", file, "Does not exist");
        print("Critical Image  file missing in installation, - Need to reinstall Peak Works ")
        print("Exiting.... ")
        return False 

      R_OK_flag = os.access(file , os.R_OK) # Check for read access
      if (R_OK_flag == False):
          print("Image file ", file , "does not have read permission, pls correct this")
          print("Exiting....")
          return False 

  print("Peak Works Image files : Verified: OK")
  return True
def VerifyADS115():

  p = subprocess.Popen(['i2cdetect', '-y','1'],stdout=subprocess.PIPE,)
  for i in range(0,9):
    line = str(p.stdout.readline())
    #print(line)
  for match in re.finditer("[0-9][0-9]:.*[0-9][0-9]", line):
    print (match.group())    
    return False 
  print("Peak Works Data Acquistion CARD Verified: OK")
  return True

def VerifyInstallation():
  # Delete previous Verification OK file 
  
  if(os.path.exists("PIDVERIFIED.OK") == True):
    os.remove("PIDVERIFIED.OK")
  if (VerifyPIDSettings() == False):
      print("Peak Works  Environment Verification Failed")
      exit(0)
  if (VerifyDataFiles()   == False):
     print("Peak Works  Environment Verification Failed")
     exit(0)
  if (VerifyImageFiles() == False):
     print("Peak Works  Environment Verification Failed")
     exit(0)
  if (VerifyADS115() == False):
     print("Peak Works  Environment Verification Failed")
     exit(0)
  
  print("Peak Works  Environment Verification Completed")
  fp = open("PIDVERIFIED.OK", "w")
  fp.write("Verified")   
  fp.close()
  return

          
if __name__ == '__main__':
  VerifyInstallation()

