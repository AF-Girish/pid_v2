#! /usr/bin/python3
import json
import time
import sys
import os
import csv
import threading
import datetime
from tkinter import *
from tkinter.filedialog import askopenfilename
from tkinter.messagebox import showinfo
from tkinter import ttk
from tkinter import messagebox
print("Loading Libraries ... pls wait for few seconds....")
import detectorpopup as DetectorClass
import methodedit as methodEditClass
import componentstable as ComponentsTable
import standardstable as StandardsTable
import pidpreferences as PIDPreferences
import runmenu as RunMenu
import pid_graph as PIDGraph
import filemenuoptions as FileMenuOptions
import viewmenuoptions as ViewMenuOptions
import helpClass       as HelpClass
import  pid_settings   as PidSettings
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg,NavigationToolbar2Tk)
#from daqhats import hat_list, HatIDs, mcc118
from threading import Lock
from scipy.integrate import simps
import board
import busio

import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

#import numpy as np
#from os.path import expanduser

global channel_number1
global channel_number2

channel_number1 = 0  
channel_number2 = 1 

#global ADS1115_BoardOneChannelZero
#global ADS1115_BoardOneChannelOne
#global ADS1115_BoardOneChannelTwo
#global ADS1115_BoardOneChannelThree

#global ADS1115_BoardTwoChannelZero
#global ADS1115_BoardTwoChannelOne
#global ADS1115_BoardTwoChannelTwo
#global ADS1115_BoardTwoChannelThree

global x_gc
global gc_values
global x_gcB
global gc_valuesB
global board 
global value_BB,start_timeB,read_values


global root 
global detectorAObject
global detectorBObject
global methodEditObject 
global componentsTableObject
global standardsTableObject
global PIDPreferencesObject
global RootWindowDetailsObject
fontString = 'Courier 10'
fontSize = 10

global yA_values_forSavefile,yB_values_forSavefile,A_Flag,B_Flag,xA_values_forSavefile,xB_values_forSavefile
yA_values_forSavefile = []
yB_values_forSavefile = []
xA_values_forSavefile = []
xB_values_forSavefile = []
B_Flag = 0
A_Flag = 0
global acquire_value,acquireButton
acquire_value = 1



def stubedout():
    return
	
 
	
def DisplayHelp():
    # -------------------------------------------
    # Populate with the code to display help here
	# -------------------------------------------
    return
	
    
def MethodSavePopup():
    #global root
    #showinfo("Method Save", "Use SaveAs Option")
    return
	
def AboutCallBack():
    return
               
 
def GenerateAndSaveReportWrapper():
    GenerateAndSaveReport(useDetectorFlag=True,
                          needDetectorAReport=False, 
                          needDetectorBReport=False,
                          includeTable=True,
                          includeGraph = True,
                          includeMethod = False,
                          includeComponents = False,
                          includeStandards = False,
 
                         )
    return
	
def CreateFileMenu(toplevel):
    FileMenu = Menubutton(toplevel, 
                          text='File', 
                          font=(fontString, fontSize),
                          underline=0)
                          
    FileMenu.pack(side=LEFT, padx="2m")
    FileMenu.menu = Menu(FileMenu,tearoff=0)
    
    FileMenu.menu.add_command(label='New', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=NewFunctionCallback)
    FileMenu.menu.add_command(label='Open', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=FileOpenWrapper)
    FileMenu.menu.add_command(label='Save', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=FileSaveWrapper)
    FileMenu.menu.add_command(label='Save As', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=FileSaveAsWrapper)                              
    
    FileMenu.menu.add_separator()
    
    FileMenu.menu.add_command(label='Generate Report', 
                              underline=0, 
                              font=(fontString, fontSize),
                              #command=FileSaveReportWrapper)
                              command=GenerateAndSaveReportWrapper)
    FileMenu.menu.add_command(label='Print Report', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=FilePrintReportWrapper)
    FileMenu.menu.add_separator()
    
    FileMenu.menu.add_command(label='Print Setup', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    FileMenu.menu.add_separator()
    FileMenu.menu.add_command(label='Page Setup', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    FileMenu.menu.add_separator()                          
    
    FileMenu.menu.add_command(label='Quit', 
                              underline=0, 
                              background='white', 
                              activebackground='green', 
                              command=FileMenu.quit)
                              
    FileMenu['menu'] = FileMenu.menu
	
    return FileMenu

def CreateEditMenu(toplevel):
    EditMenu = Menubutton(toplevel, 
                          text='Edit', 
                          font=(fontString, fontSize),
                          underline=0)
                          
    EditMenu.pack(side=LEFT, padx="2m")
    EditMenu.menu = Menu(EditMenu,tearoff=0)
    
    EditMenu.menu.add_command(label='Copy', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    EditMenu.menu.add_command(label='Copy to File', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    EditMenu['menu'] = EditMenu.menu
    return EditMenu

    
def CreateViewMenu(toplevel):
    ViewMenu = Menubutton(toplevel, 
                          text='View', 
                          font=(fontString, fontSize),
                          underline=0)
                          
    ViewMenu.pack(side=LEFT, padx="2m")
    ViewMenu.menu = Menu(ViewMenu,tearoff=0)
    
    ViewMenu.menu.add_command(label='Font', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    ViewMenu.menu.add_command(label='Axis', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=ViewMenuOptionsObject.AxisForGraphPopUp)
    ViewMenu.menu.add_command(label='Curve', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    ViewMenu.menu.add_command(label='Zoom+', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    ViewMenu.menu.add_command(label='Zoom-', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    ViewMenu.menu.add_command(label='Scale Peaks', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    ViewMenu.menu.add_command(label='No Scaling', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)


    ViewMenu['menu'] = ViewMenu.menu
    return ViewMenu


def CreateMethodMenu(toplevel):
    global detectorAObject
    global detectorBObject
    global methodEditObject 
   
    MethodMenu = Menubutton(toplevel, 
                          text='Method', 
                          font=(fontString, fontSize),
                          underline=0)
                          
    MethodMenu.pack(side=LEFT, padx="2m")
    MethodMenu.menu = Menu(MethodMenu,tearoff=0)
    #--------------------------------------------
    MethodMenu.menu.add_command(label='Edit', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=methodEditObject.MethodEditEntry)
    MethodMenu.menu.add_separator()
    
    MethodMenu.menu.add_command(label='Detector A', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=detectorAObject.DetectorPopUp)
    MethodMenu.menu.add_command(label='Detector B', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=detectorBObject.DetectorPopUp)
    MethodMenu.menu.add_separator()
    
    MethodMenu.menu.add_command(label='Components', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=componentsTableObject.TablePopUp)
    MethodMenu.menu.add_command(label='Standards', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=standardsTableObject.TablePopUp)
    MethodMenu.menu.add_separator()
    
    MethodMenu.menu.add_command(label='Save', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=MethodSavePopup)

 
    MethodMenu['menu'] = MethodMenu.menu
    return MethodMenu

# ------------------------------------- All Call back wrappers are defined below -------------------
# Some of the call back give rise to pop ups. These popups will not be seen when Graphs/Table are show
# So before calling any build in dialog where we do not have control over the TopLevel Attribute
# we use wrapped to push all graphs below and once the dialog is closed the graphs comes back
    
def SaveIntegrationResultsWrapper():
    PIDGraphObject.PushPlotsAndTableDown()
    RunMenuRunsObject.SaveIntegrationResults()
    PIDGraphObject.PushPlotsAndTableUp()
    return

def NewFunctionCallback():
    global acquireButton
    global stopButton
    global read_values
    global A_Flag
    global B_Flag

    PIDGraphObject.CloseAll()
    acquireButton["state"] = ACTIVE
    stopButton["state"] = DISABLED
    A_Flag = 0
    B_Flag = 0
    detectorAObject.LengthStr.set("1.0")
    detectorAObject.TimeStr.set("0.5")
    detectorBObject.LengthStr.set("1.0")
    detectorBObject.TimeStr.set("0.5")
    read_values = True
    FileMenuOptionsObject.SaveFile.set("None")
    InitializeVaribales() # Remove all old values and rest the board 
    return

def FileOpenWrapper():
    PIDGraphObject.PushPlotsAndTableDown()
    FileMenuOptionsObject.FileMenuOpen()
    PIDGraphObject.PushPlotsAndTableUp()
    Jobfilename = FileMenuOptionsObject.LoadFile.get()
    #print("DEBUG: FileOpenWrapper Jobfile name ",Jobfilename)
    FileMenuOptionsObject.LoadFile.set(Jobfilename)
    acquireButton["state"] = DISABLED
    if (Jobfilename == ''):
        return # User pressed CANCEL Button

    if (Jobfilename.endswith('.JOB') == False):
        showinfo("Wrong File Type", "You need to select a .JOB file, try again ..")
        return # User selected a wrong file 

    PIDGraphObject.JOBFileName = Jobfilename 
    
    # First open the JOB file 
    try:
       #print("DEBUG: Job file name",Jobfilename)
       jsonFileHandle = open(Jobfilename)
    except ValueError as IOError:
       showinfo("File opening failed ", "Unable to open the JOB file, check permissions etc.")
       return False

       
    # Load the  JOB file 
    try:
       data = json.load(jsonFileHandle)
    except ValueError as e:
       showinfo("Incorrect Format", "JOB file is not in correct format, seems to be corrupted")
       return False

    # Close the JOB file  
    jsonFileHandle.close()
    #print("DEBUG:FileOpenWrapped", data['Detector A'] , " ",  data['Detector B']) 
    if data['Detector A'] == "ON" :
        detectorAObject.OnOffFlag.set(True)
    else:
        detectorAObject.OnOffFlag.set(False)
    
    #print("DEBUG: FileOpenWrapper detectorAObject.OnOffFlag",  detectorAObject.OnOffFlag.get() ) 
    if data['Detector B'] == "ON" :
        detectorBObject.OnOffFlag.set(True)
    else:
        detectorBObject.OnOffFlag.set(False)
    #print("DEBUG: FileOpenWrapper detectorBObject.OnOffFlag",  detectorAObject.OnOffFlag.get() ) 

    if detectorAObject.OnOffFlag.get():
        PIDGraphObject.aX_Save_values = []
        PIDGraphObject.aY_Save_values = []
        #print("DEBUG: CSV File name :", data['Detector-A-Data'])

        with open(data['Detector-A-Data'],'r') as file:
            csvreader = csv.reader(file)
            header = next(csvreader)
            for row in csvreader:
                #print("DEBUG:FileOpenWrapper: Row=",row)
                row_A0 = float(row[0])
                row_A1 = float(row[1])
                PIDGraphObject.aX_Save_values.append(row_A0)
                PIDGraphObject.aY_Save_values.append(row_A1)
        PIDGraphObject.PopUpGraphA_Cons()
        #print("DEBUG: FileOpenWrapper:No of rows read = ", len(PIDGraphObject.aY_Save_values))
    else:
        pass
    if detectorBObject.OnOffFlag.get():
        PIDGraphObject.bX_Save_values = []
        PIDGraphObject.bY_Save_values = []
        with open(data['Detector-B-Data'],'r') as file:
            csvreader = csv.reader(file)
            header = next(csvreader)
            for row in csvreader:
                row_B0 = float(row[0])
                row_B1 = float(row[1])
                PIDGraphObject.bX_Save_values.append(row_B0)
                PIDGraphObject.bY_Save_values.append(row_B1)
        PIDGraphObject.PopUpGraphB_Cons()
    else:
        pass

    return

'''
def FindCompoundName(observed_retention_time):

    print("DEBUG: FindCompoundName, time = ",observed_retention_time) 
    rows = []
    fields = []
   
    #with open("ComponentA.csv", 'r') as csvfile:
    #    csvreader = csv.reader(csvfile)
    #
    #    fields = next(csvreader)
    #
    #    for row in csvreader:
    #        #print("DEBUG: FindCompoundName: row= ",row)
    #        rows.append(row)

    rows  = componentsTableObject.ComponentsTableAData 
    for row in rows:
       # print("DEBUG: Component Table :", row)
        PeakRTForACompound = float(row[2])
        print("FindCompoindName: ", PeakRTForACompound)
        window = float(row[3])

        # Check whether the give observed_retention_time is matching with 
        # the retention time of the current Compound in the Component Table 
        #
        # 
        # We have a window, if the Observerd RT falls within the window we 
        # consider the given compound is matching with the current compound in the
        # table.
        print("DEBUG FindCompound", (PeakRTForACompound-window),   observed_retention_time, ( PeakRTForACompound + window))

        if PeakRTForACompound - window < observed_retention_time < PeakRTForACompound + window:
            # This compound't Peak RT is matching with the given rentention time
            print("DEBUG: FindCompound: ", row[0], "RT", observed_retention_time)
            CompoundName = row[0]
            return CompoundName 

    # Observered Retention time did not match with any of the given compounds 
    # So this compound/gas will be marked as Unknown
    return "Unknown"

def CalculatePeakAreaAndHeight(x,y):

    global detectorAObject
    curve_ListA = []
    data_ListA = []
    data_List_aY = []
    data_List_aX = []
    curveList_aY = y
    curveList_aX = x
    peak_rt = 0.0
    max_data = 0.0

    global componentsTableObject

    print("DEBUG:CalculatePeakAreaAndHeight")
    for curveValue_aX,curveValue_aY in zip(curveList_aX,curveList_aY):
        # Replace 1.0 with value from UI 
        if curveValue_aY > 1.0: 
            data_ListA.append((curveValue_aX,curveValue_aY))
            data_List_aX.append(curveValue_aX)
            data_List_aY.append(curveValue_aY)
                 
        elif not data_ListA == []:
            print("DEBUG:CalculatePeakAreaAndHeight: One cycle detected")
            #print("DEBUG:CalculatePeakAreaAndHeight: ","aX=",curveValue_aX,"aY",curveValue_aY)
            # Initalize both the variables with the
            # first value in array, so that in case the zero-th element is peak
            # we don't miss it.         
            max_data = data_List_aY[0]
            peak_rt = data_List_aX[0]
            peak_rt = round(peak_rt,2)
            for i,j in zip(data_List_aX,data_List_aY):
                if j>max_data:
                    max_data = j
                    peak_rt = i 
                    peak_rt = round(peak_rt,2)
                #print(" |DEBUG:i,j max_data" ,i, " ",j, max_data,"|", end = '')
                
            
            #print("DEBUG:CalculatePeakAreaAndHeight: ","i=",i,"j=",j)
            peak_height = max_data 
            peak_height = round(peak_height,2)
            peak_area   = simps(data_List_aY,dx=0.2)
            peak_area   = round(peak_area,2)
            #print("DEBUG: CalculatePeakAreaAndHeight","Peak Height= " ,peak_height, "Peak RT= ", peak_rt)
            compound_name = FindCompoundName(peak_rt)           

            curve_ListA.append(dict(peak_height = peak_height,
                                    peak_area = peak_area,
                                    peak_RT=peak_rt,
                                    CompoundName =compound_name))
            data_ListA = []
            data_List_aY = []
            data_List_aX = []
            peak_rt = 0.0 
            max_data = 0.0 
        else:
            #print("Length of data_List= ", len(data_ListA)) 
            #print("Length of data_List_aY= ", len(data_List_aY)) 
            #print("Length of data_List_aX= ", len(data_List_aX))  
            pass
    return curve_ListA
'''

def FileSaveAsWrapper():
    FileMenuOptionsObject.SaveFile.set("None")
    PIDGraphObject.PushPlotsAndTableDown()
    FileMenuOptionsObject.FileMenuSaveAs()
    PIDGraphObject.PushPlotsAndTableUp()
    if (FileMenuOptionsObject.SaveFile.get() != "None"):
        FileSaveWrapper()
    return
    
def FileSaveReportWrapper():
    PIDGraphObject.PushPlotsAndTableDown()
    FileMenuOptionsObject.SaveReport()
    PIDGraphObject.PushPlotsAndTableUp()
    return
    
def FilePrintReportWrapper():
    PIDGraphObject.PushPlotsAndTableDown()
    FileMenuOptionsObject.PrintReportPopUp()
    PIDGraphObject.PushPlotsAndTableUp()
    pdffileName = GenerateAndSaveReport(useDetectorFlag=True,
                          needDetectorAReport=False,
                          needDetectorBReport=False,
                          includeTable=True,
                          includeGraph = True,
                          includeMethod = False,
                          includeComponents = False,
                          includeStandards = False,
                         )
    cmd = "lp " + pdffilename

    return

    
def CreateRunMenu(toplevel):
    RunMenu = Menubutton(toplevel, 
                          text='Run', 
                          font=(fontString, fontSize),
                          underline=0)
                          
    RunMenu.pack(side=LEFT, padx="2m")
    RunMenu.menu = Menu(RunMenu,tearoff=0)
  
    RunMenu.menu.add_command(label='Calibration Acquire', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=RunMenuCalibrationAcquireObject.TablePopUp)

    RunMenu.menu.add_command(label='Acquire Run', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    
   
    RunMenu.menu.add_command(label='Zero Gas Run', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
   
    RunMenu.menu.add_command(label='Integrate Run', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
   
    RunMenu.menu.add_command(label='Stop', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
                              
    RunMenu.menu.add_separator()
    
    RunMenu.menu.add_command(label='Save Integration Results', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=SaveIntegrationResultsWrapper)

    RunMenu.menu.add_command(label='Enable Oven', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    
   
    RunMenu.menu.add_command(label='Disable Oven', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
   
    RunMenu.menu.add_command(label='Open Oven Door', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
   
    RunMenu.menu.add_command(label='Close Oven Door', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    RunMenu.menu.add_separator()
    
    RunMenu.menu.add_command(label='Start Lamp A', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)

    RunMenu.menu.add_command(label='Stop Lamp A', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    
   
    RunMenu.menu.add_command(label='Start Lamp B', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
   
    RunMenu.menu.add_command(label='Stop Lamp B', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    RunMenu.menu.add_separator()
    
    RunMenu.menu.add_command(label='Select Run', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=RunMenuRunsObject.SelectRunPopUp)
                              
    RunMenu.menu.add_command(label='Edit Run', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=RunMenuRunsObject.EditRunPopUp)

    RunMenu.menu.add_command(label='Save Calibration Results', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=RunMenuRunsObject.SaveCalibrationResults)
    
    RunMenu.menu.add_separator()
    
    RunMenu.menu.add_command(label='Run Modes', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=RunMenuRunModesObject.TablePopUp)
   
    RunMenu.menu.add_command(label='Shift Modes', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
   
    RunMenu.menu.add_command(label='Auto Zero', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    RunMenu.menu.add_command(label='Autozoft', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
                     
    
    
    RunMenu['menu'] = RunMenu.menu
    return RunMenu
    
def CreateOptionsMenu(toplevel):
    OptionsMenu = Menubutton(toplevel, 
                          text='Options', 
                          font=(fontString, fontSize),
                          underline=0)
                          
    OptionsMenu.pack(side=LEFT, padx="2m")
    OptionsMenu.menu = Menu(OptionsMenu,tearoff=0)
    #===============================================
    OptionsMenu.menu.add_command(label='Preferences', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDPreferencesObject.PreferencesPopUp)
    OptionsMenu.menu.add_command(label='Save', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDPreferencesObject.PreferencesSaveOptionsPopUp)

    #===============================================
    OptionsMenu['menu'] = OptionsMenu.menu
    return OptionsMenu

def CreateWindowsMenu(toplevel):
    WindowsMenu = Menubutton(toplevel, 
                          text='Windows', 
                          font=(fontString, fontSize),
                          underline=0)
                          
    WindowsMenu.pack(side=LEFT, padx="2m")
    WindowsMenu.menu = Menu(WindowsMenu,tearoff=0)
    #===============================================
    WindowsMenu.menu.add_command(label='Cascade', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    WindowsMenu.menu.add_command(label='Tile Horizontal', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDGraphObject.TileHorizontal)
    WindowsMenu.menu.add_command(label='Tile Vertical', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    WindowsMenu.menu.add_command(label='Arrange All', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDGraphObject.ArrageAll)
    WindowsMenu.menu.add_command(label='Close All', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDGraphObject.CloseAll)
    WindowsMenu.menu.add_separator()

    WindowsMenu.menu.add_command(label='Graph A Detector A', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDGraphObject.PopUpGraphA_Cons)
    WindowsMenu.menu.add_command(label='Graph B Detector B', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDGraphObject.PopUpGraphB_Cons)
    WindowsMenu.menu.add_command(label='Table A Detector A', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDGraphObject.CreateTableA)
    WindowsMenu.menu.add_command(label='Table B Detector B', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=PIDGraphObject.CreateTableB)
    WindowsMenu.menu.add_command(label='Both Graph', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    WindowsMenu.menu.add_command(label='Run Graph', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    
    #===============================================    
    WindowsMenu['menu'] = WindowsMenu.menu
    return WindowsMenu
   
def CreateHelpMenu(toplevel):
    HelpMenu = Menubutton(toplevel, 
                          text='Help', 
                          font=(fontString, fontSize),
                          underline=0)
    
    HelpMenu.pack(side=LEFT, padx="2m")
    HelpMenu.menu = Menu(HelpMenu,tearoff=0)
    
    HelpMenu.menu.add_command(label='Contents F1', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=DisplayHelp)

    HelpMenu.menu.add_command(label='Using Help', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=stubedout)
    HelpMenu.menu.add_separator()
    
    HelpMenu.menu.add_command(label='About', 
                              underline=0, 
                              font=(fontString, fontSize),
                              command=HelpMenuObject.AboutCallBack)

    
    HelpMenu['menu'] = HelpMenu.menu
    return HelpMenu

def callback():
    return
	
#global startAcquire,StopAcquire
#startAcquire = False
#StopAcquire = True
#global value_AA,start_time
#value_AA = 1
#start_time = time.time()

# --------------------------------------------
# ADS115channelTwo.voltage will have the latest value - this is updated async 
# --------------------------------------------
def ReadDetectorAValuesFromADS1115():
    global value_AA,start_time,gc_values,read_values
    global board
    global ADS1115 
    global ADS1115_BoardOneChannelZero
    global ADS1115_BoardOneChannelOne
    global ADS1115_BoardOneChannelTwo
    global ADS1115_BoardOneChannelThree

    global ADS1115_BoardTwoChannelZero
    global ADS1115_BoardTwoChannelOne
    global ADS1115_BoardTwoChannelTwo
    global ADS1115_BoardTwoChannelThree


    global x_gc
    global gc_values
    global gcValuesB

    g_var1 = 0
    actual_time = 0

    if value_AA == 1:
        start_time = time.time()
        value_AA = 2
    ADCData = ADS1115_BoardOneChannelZero.voltage
    g_var1 = round(ADCData,6)
    #print(detectorAObject.LengthStr.get(),g_var1)

    if g_var1 < float(detectorAObject.LengthStr.get()):
        g_var1 = 0
    actual_time = time.time()-start_time
    actual_time = round(actual_time,4)
    if actual_time < float(detectorAObject.TimeStr.get()):
        g_var1 = 0
    gc_values.append(g_var1)
    x_gc.append(actual_time)
    if PIDGraphObject.plotValuesFlagA == 0:
        PIDGraphObject.plotValuesFlagA = -1
        PIDGraphObject.aX_plot_values.append(actual_time)
        PIDGraphObject.aY_plot_values.append(g_var1)
        PIDGraphObject.plotValuesFlagA = 0
    return x_gc,gc_values



#global value_BB,start_timeB,read_values
#value_BB = 1
#read_values = True
#start_timeB = time.time()

def ReadDetectorBValuesFromADS1115():
    global x_gc
    global gc_values
    #global gcValuesB
    global value_BB
    global start_timeB
    global gc_valuesB
    global read_values
    global x_gcB

    global ADS1115_BoardOneChannelZero
    global ADS1115_BoardOneChannelOne
    global ADS1115_BoardOneChannelTwo
    global ADS1115_BoardOneChannelThree

    global ADS1115_BoardTwoChannelZero
    global ADS1115_BoardTwoChannelOne
    global ADS1115_BoardTwoChannelTwo
    global ADS1115_BoardTwoChannelThree



    varB1, actual_timeB = 0, 0
    if value_BB == 1:
        start_timeB = time.time()
        value_BB = 2

    # --------------------------------------------
    # ADS1115_BoardOneChannelOne.voltage  will have the latest value - this is updated async 
    # --------------------------------------------

    ADCData = ADS1115_BoardOneChannelOne.voltage
    varB1 = round(ADCData,6)
    if varB1 < float(detectorBObject.LengthStr.get()):
        varB1 = 0
    actual_timeB = time.time()-start_timeB
    actual_timeB = round(actual_timeB,4)
    if actual_timeB < float(detectorBObject.TimeStr.get()):
        varB1 = 0
    gc_valuesB.append(varB1)
    x_gcB.append(actual_timeB)
    if PIDGraphObject.plotValuesFlagB == 0:
        PIDGraphObject.plotValuesFlagB = -1
        PIDGraphObject.bX_plot_values.append(actual_timeB)
        PIDGraphObject.bY_plot_values.append(varB1)
        PIDGraphObject.plotValuesFlagB = 0
    return x_gcB,gc_valuesB

# ##########################################################################
  ################################# Commented out ##########################
# ##########################################################################
def ReadValuesChannelA():
    global startAcquire
    global start_time
    global value_AA

    start_time = time.time()
    start_timeB = time.time()
    count = 0
    while startAcquire:
        ReadValuesAFromADS1115()
        ReadValuesBFromADS1115()
        count  = count + 1
        #print("DEBUG: No of samples read = ", count)
        SleepTime = float(PidSettingsObject.samplingIntervalTime)
        time.sleep(SleepTime) 
    PIDGraphObject.aX_plot_values = []
    PIDGraphObject.aY_plot_values = []
    PIDGraphObject.bX_plot_values = []
    PIDGraphObject.bY_plot_values = []

    return

def ReadValuesChannelB():
    global gc_valuesB
    global startAcquire
    global start_timeB
    global x_gcB
    global value_BB
    start_timeB = time.time()
    while startAcquire:
        #ReadValuesBFromADS115() 
        SleepTime = float(PidSettingsObject.samplingIntervalTime)
        time.sleep(SleepTime)
        #time.sleep(0.2)
    PIDGraphObject.bX_plot_values = []
    PIDGraphObject.bY_plot_values = []
    return

# ##########################################################################
# ####################### End of  Commented Code  #########################
# ##########################################################################


def ReadOVENTemperature():
    return

def ReadDetectorTemperature():
    return

def ReadValuesFromBothDetectors():
    global startAcquire
    global start_time
    global start_timeB
    global value_AA
    global yA_values_forSavefile
    global yB_values_forSavefile
    global xA_values_forSavefile
    global xB_values_forSavefile
    print("DEBUG: Function : ReadValuesFromBothDetectors Entered")
    if detectorAObject.OnOffFlag.get():
       print("DEBUG: Function : ReadValuesFromBothDetectors Detector A ON")
       start_time = time.time()
       Avals = ReadDetectorAValuesFromADS1115()
       xA_values_forSavefile.append(Avals[0])
       yA_values_forSavefile.append(Avals[1])

    if detectorBObject.OnOffFlag.get():
       print("DEBUG: Function : ReadValuesFromBothDetectors Detector B ON")
       start_timeB = time.time()
       Bvals = ReadDetectorBValuesFromADS1115()
       xB_values_forSavefile.append(Bvals[0])
       yB_values_forSavefile.append(Bvals[1])

    print("DEBUG: Function : ReadValuesFromBothDetectors Entering Read Loop")

    while startAcquire:
        if detectorAObject.OnOffFlag.get():
            ReadDetectorAValuesFromADS1115()
        if detectorBObject.OnOffFlag.get():
            ReadDetectorBValuesFromADS1115()

        ReadOVENTemperature()
        ReadDetectorTemperature()

        SleepTime = float(PidSettingsObject.samplingIntervalTime)
        time.sleep(SleepTime)
    print("DEBUG: Function : ReadValuesFromBothDetectors Exiting Read Loop")
    PIDGraphObject.aX_plot_values = []
    PIDGraphObject.aY_plot_values = []
    PIDGraphObject.bX_plot_values = []
    PIDGraphObject.bY_plot_values = []

    print("DEBUG: Function : ReadValuesFromBothDetectors return")

    return

def AcquireIconCallback():
    global handleTothread_A
    global handleTothread_B
    global  lock
    global A_Flag
    global B_Flag
    global startAcquire
    global yA_values_forSavefile
    global yB_values_forSavefile
    global acquire_value
    global xA_values_forSavefile
    global xB_values_forSavefile
    global acquireButton

    xA_values_forSavefile = []
    yA_values_forSavefile = []
    xB_values_forSavefile = []
    yB_values_forSavefile = []
    startAcquire = True    
    if detectorAObject.OnOffFlag.get():
       acquireButton["state"] = DISABLED
       stopButton["state"] = ACTIVE
       PIDGraphObject.PopUpGraphA()
       A_Flag = 1


    if detectorBObject.OnOffFlag.get():
       acquireButton["state"] = DISABLED
       stopButton["state"] = ACTIVE
       PIDGraphObject.PopUpGraphB()
       B_Flag = 1

    if ((detectorAObject.OnOffFlag.get() == True)  | (detectorBObject.OnOffFlag.get() == True)):
        handleTothread_A = threading.Thread(target = ReadValuesFromBothDetectors)
        handleTothread_A.start()
    return

'''
    Commented Out
    if detectorAObject.OnOffFlag.get():
        try:
            acquireButton["state"] = DISABLED
            stopButton["state"] = ACTIVE
            handleTothread_A = threading.Thread(target = ReadValuesChannelA)
            handleTothread_A.start()
            #values_thread_A.join()
            PIDGraphObject.PopUpGraphA()
            A_Flag = 1
            time.sleep(2)
            xA_values_forSavefile.append(ReadValuesAFromADS1115()[0])
            yA_values_forSavefile.append(ReadValuesAFromADS1115()[1])

        except RuntimeError:
            pass
    
    if detectorBObject.OnOffFlag.get():
        try:
            acquireButton["state"] = DISABLED
            stopButton["state"] = ACTIVE
            #handleTothread_B = threading.Thread(target = ReadValuesChannelB)
            #handleTothread_B.start()
            #values_thread_B.join()
            PIDGraphObject.PopUpGraphB()
            B_Flag = 1
            xB_values_forSavefile.append(ReadValuesBFromADS1115()[0])
            yB_values_forSavefile.append(ReadValuesBFromADS1115() [1])

        except RuntimeError:
            pass
    else:
        pass
'''  
  


def SaveSettingToJOBFile():
    
    global my_stringA
    global my_stringB
    global my_string1
    global B_Flag

    my_file1 = FileMenuOptionsObject.SaveFile.get()
    my_string1 = my_file1
    #print("DEBUG: ------------ SaveSettingToJOBFile ------------")
    #print("File name to save = ", my_string1)
    #print("DEBUG: ------------ SaveSettingToJOBFile ------------")
    my_stringA = os.path.splitext(my_string1)[0]
    my_stringA = my_stringA + '-Detector-A.csv'
    my_stringB = os.path.splitext(my_string1)[0]
    my_stringB = my_stringB + '-Detector-B.csv'

    detectorAOnOffFlag =    detectorAObject.OnOffFlag.get() 
    detectorBOnOffFlag =    detectorBObject.OnOffFlag.get() 

    if (detectorAOnOffFlag  == 1 and detectorBOnOffFlag == 1):
        my_stringA = os.path.splitext(my_string1)[0]
        my_stringA = my_stringA + '-Detector-A.csv'
        my_stringB = os.path.splitext(my_string1)[0]
        my_stringB = my_stringB + '-Detector-B.csv'
        x_AB = {
                'Detector A':"ON",'Detector B':"ON",
                "Detector-A-Data": my_stringA,"Detector-B-Data": my_stringB,
                "Detector-A-Label":detectorAObject.detectorLabelStr,
                "Detector-B-Label":detectorAObject.detectorLabelStr ,
                "Detector-A-Log":detectorAObject.detectorLogFlag,
                "Detector-B-Log":detectorBObject.detectorLogFlag,
                "Detector-A-External":detectorAObject.detectorExternalFlag,
                "Detector-B-External":detectorBObject.detectorExternalFlag,
                "Detector-A-Invert":detectorAObject.detectorInvertFlag,
                "Detector-B-Invert":detectorBObject.detectorInvertFlag,
                "Detector-A-Time":detectorAObject.detectorTimeStr,
                "Detector-B-Time":detectorBObject.detectorTimeStr,
                "Detector-A-Length":detectorAObject.detectorLengthStr,
                "Detector-B-Length":detectorBObject.detectorLengthStr,
                "Detector-A-Min Area":detectorAObject.detectorMinArea,
                "Detector-B-Min Area":detectorBObject.detectorMinArea,
                "Detector-A-Min Height":detectorAObject.detectorMinHeight,
                "Detector-B-Min Height":detectorBObject.detectorMinHeight,
                "Detector-A-Segment Width":detectorAObject.detectorSegmentWidth,
                "Detector-B-Segment Width":detectorBObject.detectorSegmentWidth,
                "Detector-A-Detector Units":detectorAObject.detectorUnits,
                "Detector-B-Detector Units":detectorBObject.detectorUnits,
                "Detector-A-Peak Algorithm":detectorAObject.detectorPeaksAlgorithm,
                "Detector-B-Peak Algorithm":detectorBObject.detectorPeaksAlgorithm,
                "Detector-A-Detect Method":detectorAObject.detectorDetectMethod,
                "Detector-B-Detect Method":detectorBObject.detectorDetectMethod, 
                "Detector-A-Data To Excel":detectorAObject.detectorDataToExcelFlag,
                "Detector-B-Data To Excel":detectorBObject.detectorDataToExcelFlag,    
                "Detector-A-Lamp Save":detectorAObject.detectorLampSaveFlag,
                "Detector-B-Lamp Save":detectorBObject.detectorLampSaveFlag,    
                "Detector-A-Auto":detectorAObject.detectorAutoFlag,
                "Detector-B-Auto":detectorBObject.detectorAutoFlag,
                "Detector-A-Range Selection":detectorAObject.detectorRangeSelection,
                "Detector-B-Range Selection":detectorBObject.detectorRangeSelection
                }
        xAB_json = json.dumps(x_AB,indent = 2)
        
        with open(my_string1,'w') as my_fileJSON:
             my_fileJSON.write(xAB_json)
        return my_stringA,my_stringB
        
    elif (detectorAOnOffFlag  == 1 and detectorBOnOffFlag == 0):
        my_stringA = os.path.splitext(my_string1)[0]
        my_stringA = my_stringA + '-Detector-A.csv'
        my_stringB = os.path.splitext(my_string1)[0]
        my_stringB = my_stringB + '-Detector-B.csv'
        x_AB = {
                'Detector A':"ON",'Detector B':"OFF",
                "Detector-A-Data": my_stringA,
                "Detector-A-Label":detectorAObject.detectorLabelStr,
                "Detector-A-Log":detectorAObject.detectorLogFlag,
                "Detector-A-External":detectorAObject.detectorExternalFlag,
                "Detector-A-Invert":detectorAObject.detectorInvertFlag,
                "Detector-A-Time":detectorAObject.detectorTimeStr,
                "Detector-A-Length":detectorAObject.detectorLengthStr,
                "Detector-A-Min Area":detectorAObject.detectorMinArea,
                "Detector-A-Min Height":detectorAObject.detectorMinHeight,
                "Detector-A-Segment Width":detectorAObject.detectorSegmentWidth,
                "Detector-A-Detector Units":detectorAObject.detectorUnits,
                "Detector-A-Peak Algorithm":detectorAObject.detectorPeaksAlgorithm,
                "Detector-A-Detect Method":detectorAObject.detectorDetectMethod,
                "Detector-A-Data To Excel":detectorAObject.detectorDataToExcelFlag,
                "Detector-A-Lamp Save":detectorAObject.detectorLampSaveFlag,
                "Detector-A-Auto":detectorAObject.detectorAutoFlag,
                "Detector-A-Range Selection":detectorAObject.detectorRangeSelection,
                }
        xAB_json = json.dumps(x_AB,indent = 2)
        my_file1.write(xAB_json)
        return my_stringA,my_stringB
    
    elif (detectorAOnOffFlag  == 0 and detectorBOnOffFlag == 1):
        my_stringA = os.path.splitext(my_string1)[0]
        my_stringA = my_stringA + '-Detector-A.csv'
        my_stringB = os.path.splitext(my_string1)[0]
        my_stringB = my_stringB + '-Detector-B.csv'
        x_AB = {
            'Detector A':"OFF",'Detector B':"ON",
            "Detector-B-Data": my_stringB,
            "Detector-B-Label":detectorBObject.detectorLabelStr,
            "Detector-B-Log":detectorBObject.detectorLogFlag,
            "Detector-B-External":detectorBObject.detectorExternalFlag,
            "Detector-B-Invert":detectorBObject.detectorInvertFlag,
            "Detector-B-Time":detectorBObject.detectorTimeStr,
            "Detector-B-Length":detectorBObject.detectorLengthStr,
            "Detector-B-Min Area":detectorBObject.detectorMinArea,
            "Detector-B-Min Height":detectorBObject.detectorMinHeight,
            "Detector-B-Segment Width":detectorBObject.detectorSegmentWidth,
            "Detector-B-Detector Units":detectorBObject.detectorUnits,
            "Detector-B-Peak Algorithm":detectorBObject.detectorPeaksAlgorithm,
            "Detector-B-Detect Method":detectorBObject.detectorDetectMethod, 
            "Detector-B-Data To Excel":detectorBObject.detectorDataToExcelFlag,    
            "Detector-B-Lamp Save":detectorBObject.detectorLampSaveFlag,    
            "Detector-B-Auto":detectorBObject.detectorAutoFlag,
            "Detector-B-Range Selection":detectorBObject.detectorRangeSelection, 
            }
        xAB_json = json.dumps(x_AB,indent = 2)
        my_file1.write(xAB_json)
        return my_stringA,my_stringB
    else:
        return my_stringA,my_stringB

def SaveDetectorADataToExcel(csvFileName):
    global xA_values_forSavefile
    global yA_values_forSavefile
    #print("DEBUG:SaveDetectorADataToExcel file Name=",csvFileName)
    with open(csvFileName,'w') as csvFileAHandle:
         for itemA,itemAA in zip(xA_values_forSavefile,yA_values_forSavefile):
             #csvFileAHandle.write("Time A,Detector A,")
             csvFileAHandle.write("\n")
             for i,j in zip(itemA,itemAA):
                 i = str(i)
                 csvFileAHandle.write(i)
                 csvFileAHandle.write(",")
                 j = str(j)
                 csvFileAHandle.write(j)
                 csvFileAHandle.write("\n")

def SaveDetectorBDataToExcel(csvFileName):
    global xB_values_forSavefile
    global yB_values_forSavefile

    with open(csvFileName,'w') as csvFileBHandle:
         for itemB,itemBB in zip(xB_values_forSavefile,yB_values_forSavefile):
             #csvFileBHandle.write("Time B,Detector B,")
             csvFileBHandle.write("\n")
             for i,j in zip(itemB,itemBB):
                 i = str(i)
                 csvFileBHandle.write(i)
                 csvFileBHandle.write(",")
                 j = str(j)
                 csvFileBHandle.write(j)
                 csvFileBHandle.write("\n")

def FileSaveWrapper():
    PIDGraphObject.PushPlotsAndTableDown()
    FileMenuOptionsObject.FileMenuSave()
    detectorADataFileName ,detectorBDataFileName = SaveSettingToJOBFile()

    #print("--------------- FileSaveWrapper --------------")
    #print(detectorADataFileName)
    #print(detectorBDataFileName)
    #print("detectorAObject.detectorDataToExcelFlag= ", 
    #       detectorAObject.dataToExcelFlag.get())

    #print("detectorBObject.detectorDataToExcelFlag= ", 
    #       detectorBObject.dataToExcelFlag.get())

    if detectorAObject.dataToExcelFlag.get() == True:
       SaveDetectorADataToExcel(detectorADataFileName)

    if detectorBObject.dataToExcelFlag.get() == True:
       SaveDetectorBDataToExcel(detectorBDataFileName)

    #print("--------------- FileSaveWrapper --------------")

    showinfo("Report", "Saving Completed")

    PIDGraphObject.PushPlotsAndTableUp()
    return

def GenerateAndSaveReport(useDetectorFlag=True, needDetectorAReport=False, needDetectorBReport=False,
                          includeTable=True, includeGraph = True, includeMethod = False, includeComponents = False,
                          includeStandards = False):

    Jobfilename = FileMenuOptionsObject.LoadFile.get()
    if (Jobfilename == "None"):
        showinfo("Project Not Set", "Open Job File first")
        return
    projectName = projectName = os.path.splitext(Jobfilename)[0]
    htmlFileName = projectName + ".html"   
    PDFFileName = projectName + ".pdf"   

    if (useDetectorFlag == True):
       detectorAFlag =  detectorAObject.OnOffFlag.get()
       detectorBFlag =  detectorBObject.OnOffFlag.get()
    else:
       # This is  request from Print Menu
       detectorAFlag =  needDetectorAReport 
       detectorBFlag =  needDetectorBReport 
    
    attempts = 0
    while True:   # repeat until the try statement succeeds
       try:
           # Try to open the file for writing
           fp = open(htmlFileName,"w")
           break     # exit the loop
       except IOError:
            attempts = attempts + 1
            if (attempts > 3):
                msg = "Unable to open file " +  htmlFileName
                print("Unable to open file ", htmlFileName)
                print("Check for permissions")
                PIDGraphObject.PushPlotsAndTableDown()
                showinfo("Error", msg) 
                PIDGraphObject.PushPlotsAndTableUp()
                return
            # else restart the loop

    fp.write("<HTML>\n")
    #img_tag = "<img src=\"" + "pid_analyzer.png"  + "\" >\n"
    #fp.write(img_tag)
    fp.write("<CENTER> <H1> PID Analyzer Report </H1> </CENTER>\n")
  
    date_today = datetime.date.today()
    date_str =  "<CENTER> <H3> Date : " + str(date_today.day) + "-" + date_today.strftime('%B') + "-" + str(date_today.year) + date_today.strftime('%A')
    date_str = date_str + "</H3> </CENTER>\n" 
    fp.write(date_str)
    fp.write("<HR>\n")
    fp.write("<HR>\n")
    table_header = "<head> <style> table, th, td { border: 1px solid black; } </style> </head>"
    fp.write(table_header)


    if (detectorAFlag == True): 
       jpgFileName = projectName + "-Detector-1" + ".jpg" 
       img_tag = "<img src=\"" + jpgFileName + "\" >\n"
       fp.write(img_tag)
 
    fp.write("<HR>\n")
    fp.write("<HR>\n")
    fp.write("<HR>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    fp.write("<CENTER> <H2> PID Analyzer Report </H2> </CENTER>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    if (includeMethod == True):
       fp.write("<H3> Method </H3> \n")
       fp.write("<TABLE style=\"width:100%\">\n")
       fp.write("<TR>\n") 
       content  = "<B>INJ/DET Temp = </B> "  + methodEditObject.InjDetTemprature.get() 
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "</TD>\n"
       fp.write(dataString)


       content  = "<B>Analysis Time = </B> "  + methodEditObject.analysis_time.get() 
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "</TD>\n"
       fp.write(dataString)   

       content  = "<B>Inject Time = </B> "  + methodEditObject.inject_time.get() 
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "</TD>\n"
       fp.write(dataString)

       fp.write("</TR>\n")

       fp.write("<TR>\n")  
      
       content  = "<B>Oven Temp = </B> "  + methodEditObject.OvenTemp.get() 
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "</TD>\n"
       fp.write(dataString)
    

       
       content  = "<B>Sample Time = </B>  "  + methodEditObject.sample_time.get() 
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "</TD>\n"
       fp.write(dataString)
       
       fp.write("\n</TR>\n")

       fp.write("<TR>\n")  
       content  = "<B>Syringe Inj = </B> "  + str(methodEditObject.SyringeInjFlag.get()) 
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "\n</TD>\n"
       fp.write(dataString)

       content  = "<B>Alarms = Off </B>\n "  
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "\n</TD>\n"
       fp.write(dataString)

       content  = "<B>Cont Pump = Off </B>\n "  
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "\n</TD>\n"
       fp.write(dataString)
       fp.write("</TR>\n")

       fp.write("<TR>\n")  
       content  = "<B>Calibration Cycle  =  </B> "  + methodEditObject.calibrationCycle.get()
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "\n</TD>\n"
       fp.write(dataString)


       content  = "<B>Repeat Cycle =  </B> " + methodEditObject.repeatCycle.get()
                 
       dataString = "<TD>\n"
       dataString = dataString + content 
       dataString = dataString + "\n</TD>\n"
       fp.write(dataString)
       fp.write("</TR>\n")
    
       fp.write("</TABLE>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    fp.write("<BR>\n")
    # ----------------------------  Compounds detected Table ------------------
    if (detectorAFlag == True):
       fp.write("<H3> Detector A Table </H3>\n")
       fp.write("<TABLE style=\"width:100%\" > \n")
       fp.write("<TR>\n")
       content = "<TH style=\"width:10%\"> <B>Peak No</B> </TH> <TH> <B>NAME</B> </TH>  <TH><B> Height</B></TH>  <TH><B>Area</B></TH> <TH style=\"width:10%\" > <B>Retention  Time </B></TH>"
       fp.write(content)
       fp.write("</TR>\n")
       DataInTableA  = PIDGraphObject.TableAData
       rowNo = 1 

       for entry in DataInTableA:
          compoundName = entry[0]
          peakHeight = entry[2]
          peakArea = entry[4]
          retentionTime = entry[5]
          fp.write("<TR>\n")
          content = "<TD>" + str(rowNo) + "</TD>"
          content = content + "<TD>" + compoundName + "</TD>\n"
          content = content + "<TD>" + str(peakHeight)+ "</TD>\n"
          content = content + "<TD>" + str(peakArea)+ "</TD>\n"
          content = content + "<TD>" + str(retentionTime)+ "</TD>\n"
          fp.write(content)
          fp.write("</TR>\n")
          rowNo = rowNo + 1
        
       fp.write("</TABLE>\n")
       fp.write("<BR>\n")
       fp.write("<BR>\n")
       fp.write("<BR>\n")

    if (detectorBFlag == True):
       jpgFileName = projectName + "-Detector-2" + ".jpg" 
       img_tag = "<img src=\"" + jpgFileName + "\" >\n"
       fp.write(img_tag)
    # ----------------------------  Compounds detected Table B ------------------
      
    if (detectorBFlag == True):
       fp.write("<H3> Detector B Table </H3>\n")
       fp.write("<TABLE style=\"width:100%\" >\n")
       fp.write("<TR>\n")
       content = "<TD> <B>Peak No</B> </TD> <TD> <B>NAME</B> </TD>  <TD><B> Height</B></TD>  <TD><B>Area</B></TD> <TD> <B>Retention  Time </B></TD>"
       fp.write(content)
       fp.write("</TR>\n")
       DataInTableB  = PIDGraphObject.TableBData
       rowNo = 1 
       for entry in DataInTableB:
          compoundName = entry[0]
          peakHeight = entry[2]
          peakArea = entry[4]
          retentionTime = entry[5]
          fp.write("<TR>\n")
          content = "<TD>" + str(rowNo) + "</TD>"
          content = content + "<TD>" + compoundName + "</TD>\n"
          content = content + "<TD>" + str(peakHeight)+ "</TD>\n"
          content = content + "<TD>" + str(peakArea)+ "</TD>\n"
          content = content + "<TD>" + str(retentionTime)+ "</TD>\n"
          fp.write(content)
          fp.write("</TR>\n")
          rowNo = rowNo + 1
    
       fp.write("</TABLE>\n")
       fp.write("</HTML>\n")
       fp.close()

    # Check  whether the HTML file was generated or nor 
    htmlFileCreated = os.path.exists(htmlFileName)
    if (htmlFileCreated == False):
           msg = "Report " + PDFFileName + "Not Generated  An Error occured"
           PIDGraphObject.PushPlotsAndTableDown()
           showinfo("Report", msg)
           PIDGraphObject.PushPlotsAndTableUp()
           return 
   
    # Check the file size of report to verify it is not a empty file
    file_size = os.path.getsize(htmlFileName)
    if (file_size ==  0):
        msg = "Report " + PDFFileName + "Not Generated  An Error occured"
        PIDGraphObject.PushPlotsAndTableDown()
        showinfo("Report", msg)
        PIDGraphObject.PushPlotsAndTableUp()
        return 

    # Generate PDF from HTML
    margin_options = '-B 13 -L 13 -R 13 -T 53 --header-html '
    cmd = '/usr/bin/wkhtmltopdf ' 
    cmd = cmd +  '--margin-top 10.1 --enable-local-file-access '
    cmd = cmd +  htmlFileName + ' ' + PDFFileName
    os.system(cmd)

    # Delete HTML file
    #cmd = '/bin/rm -f ' + htmlFileName
    #os.system(cmd)

    # Check Whether the Report PDF  is generated successfully 
    PDFFileCreated = os.path.exists(PDFFileName)
    if (PDFFileCreated == False):
        msg = "Report " + PDFFileName + "Not Generated  An Error occured"
        PIDGraphObject.PushPlotsAndTableDown()
        showinfo("Report", msg)
        PIDGraphObject.PushPlotsAndTableUp()
        return 

    # Check the file size of report to verify it is not a empty file
    file_size = os.path.getsize(PDFFileName)
    if (file_size > 0):
        msg = "Report " + PDFFileName + " Generated Successfully"
    else:
        msg = "Report " + PDFFileName + "Not Generated  An Error occured"
        
    PIDGraphObject.PushPlotsAndTableDown()
    showinfo("Report", msg)
    PIDGraphObject.PushPlotsAndTableUp()
    return PDFFileName

def Stopcallback():
    global handleTothread_A
    global handleTothread_B
    global read_values
    global A_Flag
    global B_Flag
    global x_gc
    global gc_values
    global x_gcB
    global gc_valuesB
    global startAcquire
    global StopAcquire
    global main_stoping_thread
    global handleTothread_B

    x_gc = []
    gc_values = []
    x_gcB = []
    gc_valuesB = []
    startAcquire = False
    print("DEBUG:Stopcallback:Called 1")
    if A_Flag == 1:
        print("DEBUG:Stopcallback:Called 2")
        PIDGraphObject.stop_threading_A()
        print("DEBUG:Stopcallback:Called 3")
        handleTothread_A.join(6)
        print("DEBUG:Stopcallback:Thread A Stopped ")
        time.sleep(1)
    if B_Flag == 1:
        PIDGraphObject.stop_threading_B()
        #handleTothread_B.join(6)
        time.sleep(1)
        print("DEBUG:Stopcallback:Thread B Stopped")
    read_values = False
    stopButton["state"] = DISABLED
    showinfo("Report", "Data Capture Completed")

    return 

def CreateStatusBar(top):
        statusBar = ttk.Label(root, text="Oven=829C, Det 823C A:10, B:10, Flow: 0.0", relief=GROOVE, anchor=W)
        statusBar.pack(side=BOTTOM, fill=X)
        
def Loadcallback_plot():
    PIDGraphObject.PushPlotsAndTableDown()
    FileMenuOptionsObject.FileMenuOpen()
    PIDGraphObject.PushPlotsAndTableUp()
    JobFilename = "" 

    JobFilename = FileMenuOptionsObject.LoadFile.get()
    PIDGraphObject.JOBFileName = Jobfilename
    acquireButton["state"] = DISABLED

    if (JobFilename == ""):
       # User has pressed Cancel
       return

    if (Jobfilename.endswith('.JOB') == False):
        showinfo("Wrong File Type", "You need to select a .JOB file, try again ..")
        return # User selected a wrong file

    # First open the JOB file
    try:
       jsonFileHandle = open(Jobfilename)
    except ValueError as IOError:
       showinfo("JOB File opening failed ", "Unable to open the JOB file, check permissions etc.")
       return False


    # Load the  JOB file
    try:
       data = json.load(jsonFileHandle)
    except ValueError as e:
       showinfo("Incorrect Format", "JOB file is not in correct format, seems to be corrupted")
       return False

    # Close the JOB file as we had read all the contents
    jsonFileHandle.close()

 
    if data['Detector A'] == "ON" :
        detectorAObject.OnOffFlag.set(True)
    else:
        detectorAObject.OnOffFlag.set(False)
        
    if data['Detector B'] == "ON" :
        detectorBObject.OnOffFlag.set(True)
    else:
        detectorBObject.OnOffFlag.set(False)
    if detectorAObject.OnOffFlag.get():
        PIDGraphObject.aX_Save_values = []
        PIDGraphObject.aY_Save_values = []
        with open(data['Detector-A-Data'],'r') as file:
            csvreader = csv.reader(file)
            header = next(csvreader)
            for row in csvreader:
                row_A0 = float(row[0])
                row_A1 = float(row[1])
                PIDGraphObject.aX_Save_values.append(row_A0)
                PIDGraphObject.aY_Save_values.append(row_A1)
        PIDGraphObject.PopUpGraphA_Cons()
    else:
        pass
    if detectorBObject.OnOffFlag.get():
        PIDGraphObject.bX_Save_values = []
        PIDGraphObject.bY_Save_values = []
        with open(data['Detector-B-Data'],'r') as file:
            csvreader = csv.reader(file)
            header = next(csvreader)
            for row in csvreader:
                row_B0 = float(row[0])
                row_B1 = float(row[1])
                PIDGraphObject.bX_Save_values.append(row_B0)
                PIDGraphObject.bY_Save_values.append(row_B1)
        PIDGraphObject.PopUpGraphB_Cons()
    else:
        pass

    showinfo("Message", "Loading Completed")

    return
def PIDQuit():
    exit(0)
    
def CreateIcons():
    global newIcon
    global loadIcon
    global saveIcon
    global printerIcon
    global exitIcon
    global acquireIcon
    global scaleNoIcon
    global stopIcon
    global runIcon
    global lampOnIcon
    global lampOffIcon
    global doorOpenIcon
    global closeIcon
    global az_bIcon
    
    IconLevelMenuBar = Frame(root, relief=FLAT, borderwidth=2)
   
    newIcon=PhotoImage(file=r'NEW.png')
    newIcon  = newIcon.subsample(1,1)
    Button(IconLevelMenuBar,image=newIcon,command = NewFunctionCallback).pack(side=LEFT)
    
  
    loadIcon=PhotoImage(file=r'LOAD.png')
    loadIcon=loadIcon.subsample(1,1)   
    Button(IconLevelMenuBar,image = loadIcon,command = FileOpenWrapper).pack(side=LEFT)

    saveIcon=PhotoImage(file=r'SAVE.png')
    saveIcon  = saveIcon.subsample(1,1)
    Button(IconLevelMenuBar,image = saveIcon,command = FileSaveWrapper).pack(side=LEFT)

    printerIcon=PhotoImage(file=r'PRINT.png')
    printerIcon  = printerIcon.subsample(1,1)
    Button(IconLevelMenuBar,image = printerIcon,command = callback).pack(side=LEFT)

    exitIcon=PhotoImage(file=r'EXIT.png')
    exitIcon  = exitIcon.subsample(1,1)
    Button(IconLevelMenuBar,image = exitIcon,command = PIDQuit).pack(side=LEFT)


    acquireIcon = PhotoImage(file=r'ACQUIRE.png')
    acquireIcon  = acquireIcon.subsample(1,1)
    
    global acquireButton,stopButton
    acquireButton = Button(IconLevelMenuBar,image = acquireIcon,command = AcquireIconCallback,state = ACTIVE)
    acquireButton.pack(side=LEFT)

    
    scaleNoIcon=PhotoImage(file=r'SCALE_NO.png')
    scaleNoIcon  = scaleNoIcon.subsample(1,1)  
    Button(IconLevelMenuBar,image = scaleNoIcon,command = callback).pack(side=LEFT)

    stopIcon =PhotoImage(file=r'STOP.png')
    stopIcon = stopIcon.subsample(1,1)  
    stopButton = Button(IconLevelMenuBar,image = stopIcon,command = Stopcallback,state = DISABLED)
    stopButton.pack(side=LEFT)

    runIcon = PhotoImage(file=r'RUN.png')
    runIcon  = runIcon.subsample(1,1)  
    Button(IconLevelMenuBar,image = runIcon,command = callback).pack(side=LEFT)
	
    lampOnIcon=PhotoImage(file=r'LAMP_ON.png')
    lampOnIcon  = lampOnIcon.subsample(1,1)  
    Button(IconLevelMenuBar,image = lampOnIcon,command = callback).pack(side=LEFT)
	
    lampOffIcon=PhotoImage(file=r'LAMP_OFF.png')
    lampOffIcon = lampOffIcon.subsample(1,1)  
    Button(IconLevelMenuBar,image = lampOffIcon,command = callback).pack(side=LEFT)

    doorOpenIcon = PhotoImage(file=r'D_OPEN.png')
    doorOpenIcon = doorOpenIcon.subsample(1,1)  
    Button(IconLevelMenuBar,image = doorOpenIcon,command = callback).pack(side=LEFT)
	
    closeIcon=PhotoImage(file=r'D_CLOSE.png')
    closeIcon = closeIcon.subsample(1,1)  
    Button(IconLevelMenuBar,image = closeIcon,command = callback).pack(side=LEFT)
   
    az_bIcon=PhotoImage(file=r'AZ_B.png')
    az_bIcon= az_bIcon.subsample(1,1)  
    Button(IconLevelMenuBar,image = az_bIcon,command = callback).pack(side=LEFT)
    
    IconLevelMenuBar.pack(fill=X,side=TOP)
		
def ActivateAcquire():
    global acquireButton
    acquireButton["state"] = ACTIVE
    return

def CreateSplashScreen(parent):
    global SplashFrame
    global photoImageObj
    global splashLabel
    
    photoImageObj = PhotoImage(file="pid_analyzer.png")
    SplashFrame = Frame(root, relief=FLAT, borderwidth=2)
    EmptyFrame = Frame(root, relief=GROOVE, borderwidth=2)
    splashLabel = Label(SplashFrame,image=photoImageObj).pack()
    EmptyFrame.pack(side=TOP)
    SplashFrame.place(relx = 0.5, rely = 0.5, anchor = 'center')
    return		
    
def CreateTopLevelMenuBar():

    TopLevelMenuBar = Frame(root, relief=RAISED, borderwidth=2)
    TopLevelMenuBar.pack(fill=X,side=TOP)
    	
    FileMenu    = CreateFileMenu(TopLevelMenuBar)
    EditMenu    = CreateEditMenu(TopLevelMenuBar)
    ViewMenu    = CreateViewMenu(TopLevelMenuBar)
    MethodMenu  = CreateMethodMenu(TopLevelMenuBar)
    RunMenu     = CreateRunMenu(TopLevelMenuBar)
    OptionsMenu = CreateOptionsMenu(TopLevelMenuBar)
    WindowsMenu = CreateWindowsMenu(TopLevelMenuBar)
    HelpMenu    = CreateHelpMenu(TopLevelMenuBar)
    CreateIcons()
    CreateStatusBar(root)
    CreateSplashScreen(root)
    #TopLevelMenuBar.tk(FileMenu, EditMenu)
    return
    
def GetMousePointsOfRoots(event):
    #print("Root Window Mouse=", "x=", event.x, "y=",event.y)
    if (SplashFrame != None):
        SplashFrame.destroy()
    return

def GetComponentListA():
  #global componentsTableObject
  print(dir(detectorAObject))
  print(dir(componentsTableObject))
  return componentsTableObject.ComponentsTableAData

def main():
  global root
  global detectorAObject
  global detectorBObject
  global methodEditObject 
  global componentsTableObject
  global standardsTableObject
  global PIDPreferencesObject 
  global RunMenuCalibrationAcquireObject
  global RunMenuRunModesObject
  global RunMenuRunsObject
  global PIDGraphObject
  global FileMenuOptionsObject
  global ViewMenuOptionsObject
  global HelpMenuObject
  global PidSettingsObject
 
  root = Tk()
  #root.geometry("1200x600") 
  root.geometry("750x380")
  root.title('PID Analyzer')

  root.geometry(("+{0}+{1}".format(10,10)))

  
  detectorAObject                 = DetectorClass.Detector("A",root)
  detectorBObject                 = DetectorClass.Detector("B",root)
  methodEditObject                = methodEditClass.MethodEdit(root)
  componentsTableObject           = ComponentsTable.ComponentsTable(root)
  standardsTableObject            = StandardsTable.StandardsTable(root)
  PIDPreferencesObject            = PIDPreferences.PIDPreferences(root)
  RunMenuCalibrationAcquireObject = RunMenu.CalibrationAcquire(root)
  RunMenuRunModesObject           = RunMenu.RunModes(root)
  PIDGraphObject                  = PIDGraph.PlotGraphClass(root)
  FileMenuOptionsObject           = FileMenuOptions.FileMenuOptions(root)
  ViewMenuOptionsObject           = ViewMenuOptions.ViewMenuOptions(root)
  HelpMenuObject                  = HelpClass.HelpClass(root)
  RunMenuRunsObject               = RunMenu.Runs(root)
  PidSettingsObject               = PidSettings.PidSettings()

  if (PidSettingsObject.ReadSettingFile() == False):
     print("PID Analyzer setting file is wrong")
     exit(0)
  if (PidSettingsObject.pidRunName == "None"):
      PidSettingsObject.pidRunName = ""

  FileMenuOptionsObject.WorkSpaceFolder.set(PidSettingsObject.workspaceFolder)
  CreateTopLevelMenuBar()
  root.bind("<Button 1>",GetMousePointsOfRoots)
  root.bind('<Configure>',PIDGraphObject.UpdateTopLeftCoordsOfRootWindow)
  root.geometry(("+{0}+{1}".format(100,100)))
  root.resizable(False, False)
  root.mainloop()

def InitializeVaribales():
  global board 
  global x_gc 
  global gc_values
  global gc_valuesB
  global  x_gcB
  global startAcquire
  global StopAcquire
  global value_AA
  global start_time
  global value_BB,start_timeB,read_values

  global ADS1115_BoardOneChannelZero
  global ADS1115_BoardOneChannelOne
  global ADS1115_BoardOneChannelTwo
  global ADS1115_BoardOneChannelThree

  global ADS1115_BoardTwoChannelZero
  global ADS1115_BoardTwoChannelOne
  global ADS1115_BoardTwoChannelTwo
  global ADS1115_BoardTwoChannelThree

  global x_gc
  global gc_values
  global x_gcB
  global gc_valuesB
  global board 


  channel_number1 = 0 # TODO need to read this from JSON 
  channel_number2 = 1 # TODO Need to read this from JSON file
 
  startAcquire = False
  StopAcquire = True
  value_AA = 1
  start_time = time.time()

  value_BB = 1
  read_values = True
  start_timeB = time.time()

  # ------------------------------------------
  # MCC 118 Code 
  # ------------------------------------------
  #board_list = hat_list(filter_by_id = HatIDs.ANY)
  #if board_list[0].id == HatIDs.MCC_118:
  #  board = mcc118(board_list[0].address)
  # ------------------------------------------
  # END OF  MCC 118 Code 
  # ------------------------------------------

  # ------------------------------------------
  # ADS1115 Initialzation  
  # ------------------------------------------
  # Create the I2C bus
  i2c = busio.I2C(board.SCL, board.SDA)

  # Create the ADC object using the I2C bus

  # TODO HARD Coding on address need to be removed 

  adsBoardOne = ADS.ADS1115(i2c,address=0x48)
# adsBoardTwo = ADS.ADS1115(i2c,address=0x49)

  # Create input  channel 0,1,2,3.
  ADS1115_BoardOneChannelZero = AnalogIn(adsBoardOne, ADS.P0)
  ADS1115_BoardOneChannelOne = AnalogIn(adsBoardOne, ADS.P1)
  ADS1115_BoardOneChannelTwo = AnalogIn(adsBoardOne, ADS.P2)
  ADS1115_BoardOneChannelThree = AnalogIn(adsBoardOne, ADS.P3)

  # Create input  channel 0,1,2,3.
  #ADS1115_BoardTwoChannelZero = AnalogIn(adsBoardTwo, ADS.P0)
  #ADS1115_BoardTwoChannelOne = AnalogIn(adsBoardTwo, ADS.P1)
  #ADS1115_BoardTwoChannelTwo = AnalogIn(adsBoardTwo, ADS.P2)
  #ADS1115_BoardTwoChannelThree = AnalogIn(adsBoardTwo, ADS.P3)

  #ADS1115 = Adafruit_ADS1x15.ADS1115()
  # ------------------------------------------
  # END of ADS 115 Initialzation  
  # ------------------------------------------


  x_gc = []
  gc_values = []
  x_gcB = []
  gc_valuesB = []

if __name__ == '__main__':
  if(os.path.exists("PIDVERIFIED.OK") == False):
    print("PID Installation has isses, please correct")
    exit(0)
  # PID is Verified now we will delete this file so that 
  # One should not  run this program with out verification  
  os.remove("PIDVERIFIED.OK")

  os.environ.__setitem__('DISPLAY', ':0.0')
  InitializeVaribales()
  main()

